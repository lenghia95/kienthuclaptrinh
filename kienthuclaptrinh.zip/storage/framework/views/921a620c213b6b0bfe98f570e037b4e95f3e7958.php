<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="content-header">
        <h1>
            <?php echo e($sliderimage->title); ?>

            <small><?php echo e(config('admin.edit')); ?></small>
        </h1>
        <!-- breadcrumb start -->
        <ol class="breadcrumb" style="margin-right: 30px;">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(config('admin.home')); ?></a></li>
            <li>
                <?php echo e($sliderimage->title); ?>

            </li>
            <li>
                <?php echo e($sliderimage->id); ?>

            </li>
            <li>
                <?php echo e(config('admin.edit')); ?>

            </li>
        </ol>

        <!-- breadcrumb end -->

    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo e(config('admin.edit')); ?></h3>
                        <div class="box-tools">
                            <div class="btn-group pull-right" style="margin-right: 5px">
                                <form action="<?php echo e(route('sliderimages.destroy',['id'=>$sliderimage->id])); ?>" method="post" onsubmit="return confirm('Bạn có chắc chắn muốn xóa?')">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" class="_method" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> <?php echo e(config('admin.delete')); ?></button>
                                </form>
                            </div>

                            <div class="btn-group pull-right" style="margin-right: 5px">
                                <a href="<?php echo e(route('sliderimages.index')); ?>" class="btn btn-sm btn-default" title="<?php echo e(config('admin.list')); ?>"><i class="fa fa-list"></i><span class="hidden-xs">&nbsp;<?php echo e(config('admin.list')); ?></span></a>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                   
                    <form action="<?php echo e(route('sliderimages.update',['id'=>$sliderimage->id])); ?>" method="post" class="form-horizontal" id="valiForm" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" class="_method" name="_method" value="PUT">
                        <div class="box-body">
                            <div class="fields-group">
                                
                                <label for="title" class="control-label"><?php echo e(config('admin.title')); ?>*</label>
                                <label for="title" generated="true" class="error"></label>
                                <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                                    <label class="error"><?php echo e($message); ?></label>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                <div class="input-group mb-10">
                                    <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                                    <input type="text" name="title" value="<?php echo e($sliderimage->title); ?>" maxlength="255" class="form-control key" placeholder="<?php echo e(config('admin.title')); ?>" required>
                                </div>

                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="image" class="control-label"><?php echo e(config('admin.image')); ?>*</label>
                                        <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
                                            <label class="error"><?php echo e($message); ?></label>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        <input type="file" class="avatar" name="image" data-initial-preview="<?php echo e(asset($sliderimage->image)); ?>" data-initial-caption="<?php echo e($sliderimage->image); ?>"/>
                                    </div>
                                </div>

                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="key" class="control-label"><?php echo e(config('admin.key')); ?>*</label>
                                        <?php if ($errors->has('key')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('key'); ?>
                                            <label class="error"><?php echo e($message); ?></label>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        <select class="form-control parent_id select2-hidden-accessible" style="width: 100%;" name="key" data-value="" tabindex="-1" aria-hidden="true" required>
                                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($slider->id); ?>" <?php echo e(($slider->id == $sliderimage->key) ? 'selected' : ''); ?>><?php echo e($slider->key); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>


                                
                                <label for="content" class="control-label"><?php echo e(config('admin.content')); ?></label>
                                <div class="input-group mb-10">
                                    <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                                    <textarea name="content" class="form-control" rows="3" placeholder="<?php echo e(config('admin.content')); ?>"><?php echo e($sliderimage->content); ?></textarea>
                                </div>
                                
                                
                                <label for="html" class="control-label">Html content</label>
                                <div class="input-group mb-10">
                                    <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                                    <textarea name="html" class="form-control" rows="3" placeholder="html content"><?php echo e($sliderimage->html); ?></textarea>
                                </div>
                                
                                
                            </div>
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer">
                            <div class="col-md-12">
                                <div class="btn-group pull-right">
                                    <button type="submit" class="btn btn-primary"><?php echo e(config('admin.submit')); ?></button>
                                </div>
                                <div class="btn-group pull-right" style="margin-right:10px">
                                    <button type="reset" class="btn btn-warning"><?php echo e(config('admin.reset')); ?></button>
                                </div>
                            </div>
                        </div>
                        <!-- /.box-footer -->
                    </form>
                </div>
            </div>
        </div>

    </section>
    <script>
        $(document).ready(function () {
            $('#valiForm').validate();
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/admins/sliderimages/edit.blade.php ENDPATH**/ ?>
<div class="fakeimg p-3 mt-2">
    
    <div class="newspaper-x-blog-sidebar">
        <div class="widget widget_categories">
            
            <div class="box-title">
                <h2 class="title">
                    <a href="javascript:void(0)">Danh mục</a>
                </h2>
            </div>
            <div class="categories mt-3">
                <ul>
                    <?php $__currentLoopData = App\Models\Category::getCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(url('category/'.$category->slug)); ?>"> 
                                <i class="fa fa-angle-double-right"></i> 
                                <?php echo e($category->name); ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>

</div>

<div class="fakeimg p-3 mt-2">

    <div class="newspaper-x-blog-sidebar">
        <div class="widget widget_categories">
            
            <div class="box-title">
                <h2 class="title">
                    <a href="javascript:void(0)">Bài viết mới</a>
                </h2>
            </div>
            <div class="post-news mt-3">
                <?php $__currentLoopData = App\Models\Post::getPosts(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($key < 5): ?>
                        <div class="mpw-post">
                            <div class="post-img main-sidebar-element">
                                <a href="<?php echo e(url('post/'.$post->slug)); ?>">
                                    <img src="<?php echo e(asset($post->thumbnail)); ?>" alt="<?php echo e($post->title); ?>" >
                                </a>
                            </div>
                            <div class="details has-feature-image">
                                <h6>
                                    <a href="<?php echo e(url('post/'.$post->slug)); ?>" title="<?php echo e($post->title); ?>"><?php echo e($post->title); ?></a>
                                </h6>
                                
                            </div>
                            <div class="mom-post-meta mom-w-meta">
                                <span class="entry-date"><i class="fa fa-clock-o"></i> <?php echo e(date('d/m/Y',strtotime($post->created_at))); ?></span>  -
                                <span class="entry-date"><i class="fa fa-eye"></i> <?php echo e($post->views); ?> - </span>
                                <span class="entry-date"><i class="fa fa-comments"></i> <?php echo e($post->comments->count()); ?> </span>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

</div>

<div class="fakeimg p-3 mt-2">
    
    <div class="newspaper-x-blog-sidebar">
        <div class="widget widget_categories">
            
            <div class="box-title">
                <h2 class="title">
                    <a href="javascript:void(0)">Bài viết xem nhiều</a>
                </h2>
            </div>
            <div class="post-news mt-3">
                <?php $__currentLoopData = App\Models\Post::getPostManyViews(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($key < 5): ?>
                        <div class="mpw-post">
                            <div class="post-img main-sidebar-element">
                                <a href="<?php echo e(url('post/'.$post->slug)); ?>">
                                    <img src="<?php echo e(asset($post->thumbnail)); ?>" alt="<?php echo e($post->title); ?>" >
                                </a>
                            </div>
                            <div class="details has-feature-image">
                                <h6>
                                    <a href="<?php echo e(url('post/'.$post->slug)); ?>" title="<?php echo e($post->title); ?>"><?php echo e($post->title); ?></a>
                                </h6>
                            </div>
                            <div class="mom-post-meta mom-w-meta">
                                <span class="entry-date"><i class="fa fa-clock-o"></i> <?php echo e(date('d/m/Y',strtotime($post->created_at))); ?></span>  -
                                <span class="entry-date"><i class="fa fa-eye"></i> <?php echo e($post->views); ?> - </span>
                                <span class="entry-date"><i class="fa fa-comments"></i> <?php echo e($post->comments->count()); ?> </span>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

</div><?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/homes/layouts/sidebar.blade.php ENDPATH**/ ?>
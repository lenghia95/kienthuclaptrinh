<?php $__env->startSection('content'); ?>
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogger\resources\views/admins/404.blade.php ENDPATH**/ ?>
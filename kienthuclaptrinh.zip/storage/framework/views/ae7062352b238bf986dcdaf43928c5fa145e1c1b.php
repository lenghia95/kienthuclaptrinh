<?php $__env->startSection('menugroup'); ?>
    <form action="<?php echo e(route('menugroups.update',['id'=>$menuGroup->id])); ?>" class="_form_bk mt-10 ml-10 mb-10" method="POST" id="valiForm">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <h3 class="modal-title ml-15" id="modalLabel"><?php echo e(config('admin.edit')); ?></h3>
        <input type="hidden" value="<?php echo e($menuGroup->id); ?>" name="id" />
        <div class="modal-body">
            <div class="fields-group row">
                <div class="form-group">
                    <div class="col-sm-12">
                        <label for="name" class="control-label"><?php echo e(config('admin.name')); ?>*</label>
                        <label generated="true" class="error"></label>
                        <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                            <label generated="true" class="error"><?php echo e($message); ?></label>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        <input type="text" name="name" value="<?php echo e($menuGroup->name); ?>" class="form-control name" placeholder="<?php echo e(config('admin.name')); ?>" required>
                        <br>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-12">
                        <label for="key" class="control-label">Menu key*</label>
                        <label for="key" generated="true" class="error"></label>
                        <?php if ($errors->has('key')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('key'); ?>
                            <label generated="true" class="error"><?php echo e($message); ?></label>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        <input type="text"  name="key" data-id="<?php echo e($menuGroup->id); ?>"  value="<?php echo e($menuGroup->key); ?>" class="form-control" placeholder="Menu key" required>
                        <br>
                        
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-12">
                        <label for="description" class="control-label"><?php echo e(config('admin.status')); ?>:</label>
                        <div class="input-group mb-10">
                            <input type="checkbox" name="status" <?php echo e(($menuGroup->status == 1) ? 'checked' : ''); ?> class="grid-switch" value="<?php echo e(($menuGroup->status == 1) ? 'on' : 'off'); ?>">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-12">
                        <label for="description" class="control-label"><?php echo e(config('admin.description')); ?></label>
                         <textarea class="form-control" placeholder="<?php echo e(config('admin.description')); ?>" cols="30" rows="3" name="description"><?php echo e($menuGroup->description); ?></textarea>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary"><?php echo e(config('admin.update')); ?></button>
            <a href="<?php echo e(route('menugroups.index')); ?>" class="btn btn-danger"><?php echo e(config('admin.close')); ?></a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.menugroups.widgets.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogger\resources\views/admins/menugroups/edit.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

     <div class="col-sm-8 col-sm-12 col-lg-8">

         <!-- Breadcrumb -->
        <div class="fakeimg p-2 mt-2">
            <div class="news-ticker" >
                <ul>
                    <li>
                        <span>
                            <a href="<?php echo e(url('')); ?>" >
                                 <span>Trang chủ</span>
                            </a>
                        </span>
                    </li>
                    <li>
                        <span>
                            <i class="fa fa-angle-double-right"></i>
                            <span class="title"><?php echo e($category->name); ?></span>
                        </span>
                    </li>
                </ul>
            </div>
        </div>
        <!-- Breadcrumb -->


        <!-- main-content -->
        <div class="main-content">
            <?php if($posts->total() == 0): ?>
                <div class="fakeimg p-2 mt-2 text-center">
                    Hiện tại chưa có bài đăng nào cho mục này!!
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="fakeimg p-3 mt-2">
                        <div class="row">
                            <div class="col-md-5">
                                <div class="newspaper-x-image">
                                    <a href="<?php echo e(url('post/'.$post->slug)); ?>">
                                        <img src="<?php echo e(asset($post->thumbnail)); ?>" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-7">
                                <h5 class="entry-title">
                                    <a href="<?php echo e(url('post/'.$post->slug)); ?>"><?php echo e($post->title); ?></a>
                                </h5>
                                <div class="newspaper-x-post-meta">
                                    <div>
                                        <div class="mom-post-meta bp-meta">
                                            <span class="author vcard">Đăng bởi: <?php echo e($post->uName); ?></span>
                                            <span>Ngày:
                                                <time class="updated"><?php echo e(date('d/m/Y',strtotime($post->created_at))); ?></time>
                                                 - <i class="fa fa-eye"> <?php echo e($post->views); ?> </i>
                                                 - <i class="fa fa-comments"> <?php echo e($post->comments->count()); ?> </i>
                                                    </span>
                                        </div>
                                        <?php $__currentLoopData = App\Models\PostCategory::getCatsByPostId($post->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(url('category/'.$cat->slug)); ?>"><span class="badge badge-warning"> <?php echo e($cat->name); ?> </span></a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <p><?php echo str_limit($post->description,120); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <ul class="pagination mt-2">
                <?php echo e($posts->appends(Request::except('page'))->onEachSide(3)->links()); ?>

                
            </ul>
        </div>
        <!-- main-content -->

    </div>

        <!-- sidebar -->

    <div class="col-sm-4 col-sm-12 col-lg-4 sticky sidebar">

        <?php echo $__env->make('homes.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('homes.layouts.fanpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

   
<?php $__env->stopSection(); ?>


<?php echo $__env->make('homes.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/homes/posts/category.blade.php ENDPATH**/ ?>
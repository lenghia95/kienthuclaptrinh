<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="content-header">
        <h1>
            <?php echo e($user->username); ?>

            <small><?php echo e(config('admin.edit')); ?></small>
        </h1>
        <!-- breadcrumb start -->
        <ol class="breadcrumb" style="margin-right: 30px;">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(config('admin.home')); ?></a></li>
            <li>
                <?php echo e($user->username); ?>

            </li>
            <li>
                <?php echo e($user->id); ?>

            </li>
            <li>
                <?php echo e(config('admin.edit')); ?>

            </li>
        </ol>

        <!-- breadcrumb end -->
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo e(config('admin.edit')); ?></h3>
                        <div class="box-tools">
                            
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create')): ?>
                                <div class="btn-group pull-right" style="margin-right: 5px">
                                    <form action="<?php echo e(route('users.destroy',['id'=>$user->id])); ?>" method="post" onsubmit="return confirm('Bạn có chắc chắn muốn xóa?')">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" class="_method" name="_method" value="DELETE">
                                        <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> <?php echo e(config('admin.delete')); ?></button>
                                    </form>
                                </div>
                                <div class="btn-group pull-right" style="margin-right: 5px">

                                    <a href="#" data-toggle="modal" data-target="#change_password" class="btn btn-sm btn-primary" title="<?php echo e(config('admin.change_password')); ?>">
                                        <i class="fa fa-edit"></i>
                                        <span class="hidden-xs">&nbsp;Change Pass</span>
                                    </a>

                                </div>
                            <?php endif; ?>
                            <div class="btn-group pull-right" style="margin-right: 5px">
                                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-sm btn-default" title="<?php echo e(config('admin.list')); ?>"><i class="fa fa-list"></i><span class="hidden-xs">&nbsp;<?php echo e(config('admin.list')); ?></span></a>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form action="<?php echo e(route('users.update',['id'=>$user->id])); ?>" method="post" class="form-horizontal" id="valiForm" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" class="_method" name="_method" value="PUT">
                        <div class="box-body">
                            <div class="fields-group">

                                <div class="form-group  ">
                                    <label for="name" class="col-sm-2  control-label"><?php echo e(config('admin.fullname')); ?></label>
                                    <div class="col-sm-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                                            <input type="text"  name="fullname" value="<?php echo e($user->fullname); ?>" class="form-control name" placeholder="<?php echo e($user->fullname); ?>">
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="address" class="col-sm-2  control-label">Address</label>
                                    <div class="col-sm-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                                            <input type="text" name="address" value="<?php echo e($user->address); ?>" class="form-control address" placeholder="Address">
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="phone" class="col-sm-2  control-label"><?php echo e(config('admin.phone')); ?></label>
                                    <div class="col-sm-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                                            <input type="number" name="phone" value="<?php echo e($user->phone); ?>" class="form-control phone" placeholder="<?php echo e(config('admin.phone')); ?>">
                                        </div>
                                        <label for="phone" generated="true" class="error"></label>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="avatar" class="col-sm-2  control-label"><?php echo e(config('admin.image')); ?></label>
                                    <div class="col-sm-8">
                                        <input type="file" class="avatar" name="avatar" data-initial-preview="<?php echo e(asset($user->avatar)); ?>" data-initial-caption="<?php echo e($user->avatar); ?>" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="roles" class="col-sm-2  control-label"><?php echo e(config('admin.roles')); ?></label>
                                    <div class="col-sm-8">
                                        <select class="form-control category" style="width: 100%;" name="roles[]" multiple="multiple" data-placeholder="<?php echo e(config('admin.roles')); ?>" data-value="">
                                            
                                        </select>
                                    </div>
                                    <label for="roles" generated="true" class="error"></label>
                                </div>
                            </div>
                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <div class="col-md-2">
                            </div>
                            <div class="col-md-8">
                                <div class="btn-group pull-right">
                                    <button type="submit" class="btn btn-primary"><?php echo e(config('admin.update')); ?></button>
                                </div>
                                <div class="btn-group pull-left">
                                    <button type="reset" class="btn btn-warning"><?php echo e(config('admin.reset')); ?></button>
                                </div>
                            </div>
                        </div>

                        <!-- /.box-footer -->
                    </form>
                </div>
            </div>
        </div>
        <!-- The modal đổi mật khẩu-->
        <div class="modal fade" id="change_password" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <h4 class="modal-title" id="modalLabel">Đổi mật khẩu</h4>
                    </div>
                    <form action="<?php echo e(route('change_password',['id'=>$user->id])); ?>" method="POST" enctype="multipart/form-data" id="changePass">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <div class="fields-group row">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label for="name" class="control-label">Old <?php echo e(config('admin.password')); ?>*</label>
                                        <label for="password_old" generated="true" class="error"></label>
                                        <div class="input-group mb-10">
                                            <span class="input-group-addon"><i class="fa fa-eye-slash fa-fw"></i></span>
                                            <input type="password" name="password_old" value="" class="form-control name" placeholder="Old password" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label for="name" class="control-label">New <?php echo e(config('admin.password')); ?>*</label>
                                        <label for="password" generated="true" class="error"></label>
                                        <div class="input-group mb-10">
                                            <span class="input-group-addon"><i class="fa fa-eye-slash fa-fw"></i></span>
                                            <input type="password" id="password" name="password" value="" class="form-control name" placeholder="<?php echo e(config('admin.password')); ?>" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label for="name" class="control-label"><?php echo e(config('admin.password_confirmation')); ?>*</label>
                                        <label for="repassword" generated="true" class="error"></label>
                                        <div class="input-group mb-10">
                                            <span class="input-group-addon"><i class="fa fa-eye-slash fa-fw"></i></span>
                                            <input type="password"  name="repassword" value="" class="form-control name" placeholder="<?php echo e(config('admin.password_confirmation')); ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary"><?php echo e(config('admin.submit')); ?></button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(config('admin.close')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $('#changePass').validate({
                rules: {
                    password_old:{
                        required:true,
                    },
                    password: {
                        required: true,
                        minlength: 6,
                        maxlength: 32
                    },
                    repassword: {
                        equalTo: "#password",
                    }
                },
            });
        });
    </script>
    <?php echo $__env->make('admins.users.validate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/admins/users/edit.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="content-header">
    <h1>
        <?php echo e($title); ?>

        <small><?php echo e(config('admin.list')); ?></small>
        <?php if($errors->any()): ?>
            <span style="color:red">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </span>
        <?php endif; ?>
    </h1>
    <!-- breadcrumb start -->
    <ol class="breadcrumb" style="margin-right: 30px;">
        <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(config('admin.home')); ?></a></li>
        <li><?php echo e($title); ?></li>
    </ol>
    <!-- breadcrumb end -->
</section>

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <div class="pull-right">
                        <div class="btn-group pull-right" style="margin-right: 10px">
                            <a class="btn btn-sm btn-twitter" title="Export"><i class="fa fa-download"></i><span class="hidden-xs"> <?php echo e(config('admin.export')); ?></span></a>
                            <button type="button" class="btn btn-sm btn-twitter dropdown-toggle" data-toggle="dropdown">
                                <span class="caret"></span>
                                <span class="sr-only">Toggle Dropdown</span>
                            </button>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="" target="_blank">All</a></li>
                                <li><a href="" target="_blank">Current page</a></li>
                                <li><a href="" target="_blank" class="export-selected">Selected rows</a></li>
                            </ul>
                        </div>

                        <div class="btn-group pull-right" style="margin-right: 10px">
                            <a href="" class="btn btn-sm btn-success" title="New" data-toggle="modal" data-target="#flipFlop">
                                <i class="fa fa-save"></i><span class="hidden-xs">&nbsp;&nbsp;<?php echo e(config('admin.new')); ?></span>
                            </a>
                        </div>

                    </div>
                   
                    <span>
                        <input type="checkbox" class="grid-select-all " />&nbsp;
                        <div class="btn-group">
                            <a class="btn btn-sm btn-default">&nbsp;<span class="hidden-xs">Action</span></a>
                            <button type="button" class="btn btn-sm btn-default dropdown-toggle" data-toggle="dropdown">
                                <span class="caret"></span>
                                <span class="sr-only">Toggle Dropdown</span>
                            </button>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="#" class="grid-batch-0">Delete</a></li>
                            </ul>
                        </div>
                    </span>
                </div>
                
                <!-- /.box-header -->
                <div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="dataTables_length" id="example_length">
                                    <label>Show
                                        <select name="item" class="form-control input-sm" onchange="if(this.value) window.location.href='?item='+this.value">
                                            <?php $__currentLoopData = config('admin.items'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item); ?>" <?php echo e((app('request')->get('item') == $item ) ? 'selected' : ''); ?>><?php echo e($item); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select> 
                                        entries
                                    </label>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div id="example_filter" class="dataTables_filter">
                                    <label>Search:
                                        <input type="search" name="search" class="form-control input-sm search-post" placeholder="Nhập từ khóa tìm kiếm..." aria-controls="example">
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <table id="" class="table table-hover table-striped table-bordered">
                                    <thead>
                                    <tr class="_table_title">
                                        <th> </th>
                                        <th>ID<a class="fa fa-fw fa-sort" href=""></a></th>
                                        <th><?php echo e(config('admin.title')); ?></th>
                                        <th><?php echo e(config('admin.image')); ?></th>
                                        <th><?php echo e(config('admin.category')); ?></th>
                                        <th>Author</th>
                                        <th><?php echo e(config('admin.status')); ?></th>
                                        <th><?php echo e(config('admin.created_at')); ?></th>
                                        <th><?php echo e(config('admin.action')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody class="post-output">
                                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <div class="icheckbox_minimal-blue">
                                                    <input type="checkbox" class="grid-row-checkbox" data-id="1" style="position: absolute; opacity: 0;">
                                                    <span> <i class="fa fa-comments"></i> </span>
                                                </div>
                                            </td>
                                            <td><?php echo e($post->id); ?></td>
                                            <td><?php echo e($post->title); ?></td>
                                            <td>
                                                <img width="100" src="<?php echo e(asset($post->thumbnail)); ?>" class="img-thumbnail" title="<?php echo e($post->title); ?>" />
                                            </td>
                                            <td>
                                                <?php $Cat = new App\Models\PostCategory ?>
                                                <?php $__currentLoopData = $Cat->getCatsByPostId($post->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="btn btn-info btn-xs"> <?php echo e($cat->name); ?> </span><br>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td>
                                                <a class="btn btn-warning btn-xs"><?php echo e($post->uName); ?></a>
                                            </td>
                                            <td>
                                                <input type="checkbox" data-key="<?php echo e($post->id); ?>" class="grid-switch-status" <?php echo e(($post->status == 1) ? 'checked' : ''); ?>>
                                            </td>
                                            <td><?php echo e(date('d/m/Y', strtotime($post->created_at))); ?></td>
                                            <td align="center">
                                                <a href="<?php echo e(route('listposts.show',[$post->id])); ?>"><i class="fa fa-eye"></i></a>
                                                <a href="<?php echo e(route('listposts.edit',['id' => $post->id])); ?>"><i class="fa fa-edit"></i></a>
                                                <a href="javascript:void(0)" data-id="<?php echo e($post->id); ?>" class="grid-row-delete">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    
                                </table>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-5">
                                <div class="dataTables_info">
                                    Showing 
                                    <?php echo e(($posts->currentPage() * $posts->perPage()) - ($posts->perPage() - 1)); ?> 
                                    to 
                                    <?php echo e(( $posts->currentPage() == $posts->lastPage() ) ? $posts->total() : $posts->currentPage() * $posts->perPage()); ?> 
                                    of 
                                    <?php echo e($posts->total()); ?> 
                                    entries
                                </div>
                            </div>
                            <div class="col-sm-7">
                                <div class="dataTables_paginate">
                                    <?php echo e($posts->appends(Request::except('page'))->links()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                
                <!-- The modal -->
                <div class="modal fade" id="flipFlop" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true" >
                    <div class="modal-dialog modal-lg" role="document" >
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <h4 class="modal-title" id="modalLabel">Add Pages</h4>
                            </div>
                            <div class="modal-body">
                                <div class="row box-body">
                                    <!-- Custom Tabs -->
                                    <div class="nav-tabs-custom">
                                        <ul class="nav nav-tabs">
                                            <li class="active"><a href="#tab_1" data-toggle="tab"><i class="fa fa-bars"></i> Basic Field</a></li>
                                            <li><a href="#tab_2" data-toggle="tab"><i class="fa fa-clock-o"></i> Seo meta</a></li>
                                        </ul>
                                        <form action="<?php echo e(route('listposts.store')); ?>" method="POST" enctype="multipart/form-data" id="valiForm">
                                            <?php echo csrf_field(); ?>
                                            <div class="tab-content">
                                                <div class="tab-pane active" id="tab_1">
                                                    <div class="box-body">
                                                        <div class="form-group">
                                                            <label for="title" class="control-label"><?php echo e(config('admin.title')); ?>*</label>
                                                            <label for="title" generated="true" class="error"></label>
                                                            <input type="text" name="title" value="<?php echo e(old('title')); ?>" maxlength="255" class="form-control title" placeholder="<?php echo e(config('admin.title')); ?>" required>
                                                        </div>
                                                            
                                                        <div class="form-group">
                                                            <label for="slug" class="control-label"><?php echo e(config('admin.slug')); ?>*</label>
                                                            <label for="slug" generated="true" class="error"></label>
                                                            <input type="text" name="slug"  value="<?php echo e(old('slug')); ?>" maxlength="255" class="form-control slug" placeholder="<?php echo e(config('admin.slug')); ?>" required>
                                                        </div>

                                                        <div class="form-group">
                                                            <label>Categories*</label>
                                                            <select class="form-control categories" style="width: 100%;" name="category[]" multiple="multiple" data-placeholder="Input Category" data-value="" required >
                                                            <?php echo $categories; ?>

                                                            </select>
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="status" class="control-label"><?php echo e(config('admin.status')); ?>:</label>
                                                            <input type="checkbox" name="status" checked  class="grid-switch-status" value="on">
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label for="thumbnail" class="control-label"><?php echo e(config('admin.image')); ?></label>
                                                            <?php if ($errors->has('thumbnail')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('thumbnail'); ?>
                                                                <label class="error"><?php echo e($message); ?></label>
                                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                            <input type="file" class="avatar" name="thumbnail"/>
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="description" class="control-label"><?php echo e(config('admin.description')); ?></label>
                                                            <textarea class="form-control" name="description" col="3" placeholder="Input <?php echo e(config('admin.description')); ?>"><?php echo e(old('description')); ?></textarea>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label for="content" class="control-label"><?php echo e(config('admin.content')); ?></label>
                                                            <textarea class="form-control" id="_content" name="content" placeholder="Input <?php echo e(config('admin.description')); ?>"><?php echo e(old('content')); ?></textarea>
                                                        </div>
                                                        
                                                    </div>
                                                    
                                                </div>
                                                <!-- /.tab-pane -->
                                                <div class="tab-pane" id="tab_2">
                                                    <div class="col-sm-12">
                                                        <label for="seo_title" class="control-label">seo_title</label>
                                                        <div class="input-group mb-10">
                                                            <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                                                            <input type="text" name="seo_title" value="" class="form-control seo_title" placeholder="tiêu đề seo">
                                                        </div>
                                                        <span class="help-block">
                                                            <i class="fa fa-info-circle"></i>&nbsp;sử dụng a-z and 0-9.
                                                        </span>
                                                    </div>
                                                    <div class="col-sm-12">
                                                        <label for="seo_description" class="control-label"><?php echo e(config('admin.description')); ?></label>
                                                        <div class="input-group mb-10">
                                                            <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                                                            <input type="text" name="seo_description" value="" class="form-control seo_description" placeholder="seo <?php echo e(config('admin.description')); ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-12">
                                                        <label for="seo_keywords" class="control-label">seo_keywords</label>
                                                        <div class="input-group mb-10">
                                                            <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                                                            <input type="text" name="seo_keywords" value="" class="form-control seo_keywords" placeholder="seo keywords">
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                 <!-- /.box-body -->
                                                 <div class="box-footer">
                                                    <div class="col-md-12">
                                                        <div class="btn-group pull-right">
                                                            <button type="submit" class="btn btn-primary"><?php echo e(config('admin.submit')); ?></button>
                                                        </div>
                                                        <div class="btn-group pull-left">
                                                            <button type="reset" class="btn btn-warning"><?php echo e(config('admin.reset')); ?></button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- /.box-footer -->
                                            </div>
                                        </form>
                                        <!-- /.tab-content -->
                                    </div>
                                </div>
                            </div>
                            <!-- nav-tabs-custom -->
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <?php echo $__env->make('admins.posts.validate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script type="text/javascript">
        
        $(document).ready(function(){

            $('.grid-select-all').iCheck({checkboxClass:'icheckbox_minimal-blue'});

            $('.grid-select-all').on('ifChanged', function(event) {
                if (this.checked) {
                    $('.grid-row-checkbox').iCheck('check');
                } else {
                    $('.grid-row-checkbox').iCheck('uncheck');
                }
            });

            $(document).on('keyup', '.search-post', function(){
               var keywork  = $(this).val();
               $.ajax({
                   type: "get",
                   url: "<?php echo e(url('/admin/ajax/search-posts')); ?>",
                   data: { keywork:keywork},
                   success: function (data) {
                    //    console.log(data); return false;
                       $('.post-output').html(data);
                   }
               });
            });

            
            // ajax delete
            $('.grid-row-delete').unbind('click').click(function() {
                var id = $(this).data('id');
                swal({
                    title: "Bạn có chắc chắn muốn xóa ?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Xác nhận",
                    showLoaderOnConfirm: true,
                    cancelButtonText: "Đóng",
                    preConfirm: function() {
                        return new Promise(function(resolve) {
                            $.ajax({
                                method: 'POST',
                                url: "<?php echo e(url('/admin/ajax/posts_del')); ?>/"+ id,
                                data: {
                                    _method: 'DELETE',
                                    _token: "<?php echo e(csrf_token()); ?>",
                                },
                                success: function(data) {
                                    $.pjax.reload('#pjax-container');
                                    resolve(data);
                                    toastr.success(data);
                                }
                            });
                        });
                    }
                }).then(function(result) {
                    var data = result.value;
                    if (typeof data === 'object') {
                        if (data.status) {
                            swal(data.message, '', 'Thành công');
                        } else {
                            swal(data.message, '', 'Lỗi');
                        }
                    }
                });
            });

            
            $('.grid-switch-status').bootstrapSwitch({
                size:'mini',
                onText: 'ON',
                offText: 'OFF',
                onColor: 'primary',
                offColor: 'default',
                onSwitchChange: function(event, state){
                    $(this).val(state ? 'on' : 'off');
                    var id = $(this).data('key');
                    $.ajax({
                        url: "<?php echo e(url('/admin/ajax/status_posts')); ?>/" + id,
                        type: "POST",
                        data: {
                            _token: "<?php echo e(csrf_token()); ?>",
                            _method: 'PUT'
                        },
                        success: function (data) {
                            toastr.success(data);
                        }
                    });
                }
            });
            

        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogger\resources\views/admins/posts/index.blade.php ENDPATH**/ ?>
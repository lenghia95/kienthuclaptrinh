<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            <?php echo e($title); ?>

            <small><?php echo e(config('admin.show')); ?></small>
        </h1>

        <!-- breadcrumb start -->
        <ol class="breadcrumb" style="margin-right: 30px;">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(config('admin.home')); ?></a></li>
            <li>
                <?php echo e($title); ?>

            </li>
            <li>
                <?php echo e($page->id); ?>

            </li>
        </ol>

        <!-- breadcrumb end -->

    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-12">
                        <div class="box box-info">
                            <div class="box-header with-border">
                                <h3 class="box-title">Pages.<?php echo e(config('admin.detail')); ?></h3>
    
                                <div class="box-tools">
                                    <div class="btn-group pull-right" style="margin-right: 5px">
                                        <form action="<?php echo e(route('pages.destroy',['id'=>$page->id])); ?>" method="post" onsubmit="return confirm('<?php echo e(config('admin.delete_confirm')); ?>')">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> <?php echo e(config('admin.delete')); ?></button>
                                        </form>
                                    </div>
                                    <div class="btn-group pull-right" style="margin-right: 5px">
                                        <a href="<?php echo e(route('pages.edit',[$page->id])); ?>" class="btn btn-sm btn-primary" title="Edit">
                                            <i class="fa fa-edit"></i><span class="hidden-xs"> <?php echo e(config('admin.edit')); ?></span>
                                        </a>
                                    </div>
                                    <div class="btn-group pull-right" style="margin-right: 5px">
                                        <a href="<?php echo e(route('pages.index')); ?>" class="btn btn-sm btn-default" title="List">
                                            <i class="fa fa-list"></i><span class="hidden-xs"> <?php echo e(config('admin.list')); ?></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <!-- /.box-header -->
                            <!-- form start -->
                            <div class="form-horizontal">
    
                                <div class="box-body">
    
                                    <div class="fields-group">
    
                                        <div class="form-group ">
                                            <label class="col-sm-2 control-label">ID</label>
                                            <div class="col-sm-8">
                                                <div class="box box-solid box-default no-margin box-show">
                                                    <!-- /.box-header -->
                                                    <div class="box-body">
                                                        <?php echo e($page->id); ?>&nbsp;
                                                    </div>
                                                    <!-- /.box-body -->
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <label class="col-sm-2 control-label"><?php echo e(config('admin.title')); ?></label>
                                            <div class="col-sm-8">
                                                <div class="box box-solid box-default no-margin box-show">
                                                    <!-- /.box-header -->
                                                    <div class="box-body">
                                                        <?php echo e($page->title); ?>&nbsp;
                                                    </div>
                                                    <!-- /.box-body -->
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <label class="col-sm-2 control-label"><?php echo e(config('admin.slug')); ?></label>
                                            <div class="col-sm-8">
                                                <div class="box box-solid box-default no-margin box-show">
                                                    <!-- /.box-header -->
                                                    <div class="box-body">
                                                        <?php echo e($page->slug); ?>&nbsp;
                                                    </div>
                                                    <!-- /.box-body -->
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="form-group ">
                                            <label class="col-sm-2 control-label"><?php echo e(config('admin.content')); ?></label>
                                            <div class="col-sm-8">
                                                <div class="box box-solid box-default no-margin box-show">
                                                    <!-- /.box-header -->
                                                    <div class="box-body">
                                                            <?php echo $page->content; ?>&nbsp;
                                                    </div>
                                                    <!-- /.box-body -->
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group ">
                                            <label class="col-sm-2 control-label">Seo title</label>
                                            <div class="col-sm-8">
                                                <div class="box box-solid box-default no-margin box-show">
                                                    <!-- /.box-header -->
                                                    <div class="box-body">
                                                        <?php echo e($page->seo_title ?? 'null'); ?>&nbsp;
                                                    </div>
                                                    <!-- /.box-body -->
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <label class="col-sm-2 control-label">Seo description</label>
                                            <div class="col-sm-8">
                                                <div class="box box-solid box-default no-margin box-show">
                                                    <!-- /.box-header -->
                                                    <div class="box-body">
                                                        <?php echo e($page->seo_description ?? 'null'); ?>&nbsp;
                                                    </div>
                                                    <!-- /.box-body -->
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <label class="col-sm-2 control-label">Seo keywords</label>
                                            <div class="col-sm-8">
                                                <div class="box box-solid box-default no-margin box-show">
                                                    <!-- /.box-header -->
                                                    <div class="box-body">
                                                        <?php echo e($page->seo_keywords ?? 'null'); ?>&nbsp;
                                                    </div>
                                                    <!-- /.box-body -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
    
                                </div>
                                <!-- /.box-body -->
                            </div>
                        </div>
                    </div>
    
                    <div class="col-md-12">
                    </div>
                </div>
            </div>
        </div>
    
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogger\resources\views/admins/pages/show.blade.php ENDPATH**/ ?>
<?php if(session('save_succeeded')): ?>
    <script type="text/javascript">
        $(function() {
            toastr.success("<?php echo e(session('save_succeeded')); ?>");
        });
    </script>
<?php endif; ?>

<?php if(session('update_succeeded')): ?>
    <script type="text/javascript">
        $(function() {
            toastr.success("<?php echo e(session('update_succeeded')); ?>");
        });
    </script>
<?php endif; ?>

<?php if(session('delete_succeeded')): ?>
    <script type="text/javascript">
        $(function() {
            toastr.success("<?php echo e(session('delete_succeeded')); ?>");
        });
    </script>
<?php endif; ?>

<?php if(session('refresh_succeeded')): ?>
    <script type="text/javascript">
        $(function() {
            toastr.success("<?php echo e(session('refresh_succeeded')); ?>");
        });
    </script>
<?php endif; ?>

<?php if(session('login_successful')): ?>
    <script type="text/javascript">
        $(function() {
            toastr.success("<?php echo e(session('login_successful')); ?>");
        });
    </script>
<?php endif; ?>

<?php if(session('failed')): ?>
    <script type="text/javascript">
        $(function() {
            toastr.danger("<?php echo e(session('failed')); ?>");
        });
    </script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\blogger\resources\views/flash-message.blade.php ENDPATH**/ ?>
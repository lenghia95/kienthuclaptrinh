<style>
.dropbtn {
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.account-content {
  text-align: left;
  display: none;
  position: absolute;
  right: -46px;
  background-color: #f1f1f1;
  min-width: 160px;
  overflow: auto;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 10000;
}

.account-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown a.t-account:hover {background-color: #ddd;}

.show {display: block;}
    </style>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark p-0">
    <div class="container p-0">

        <div class="col-md-6 col-lg-6 col-sm-6 col-6 pl-0 ">
            <ul class="navbar-nav mr-auto menu-top">
                <?php $menuList = new App\Models\Menulist; ?>
                <?php $__currentLoopData = $menuList->getMenusList('menu_top'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item p-0">
                        <a class="nav-link" href="<?php echo e(asset($menu->url)); ?>"><?php echo e($menu->name); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <div class="col-md-6 col-lg-6 col-sm-6 col-6 text-right pr-0">
            <a target="_blank" href="<?php echo e($Setting['facebook']); ?>" class="facebook"><i class="fa fa-facebook-official"></i></a>
            <a target="_blank" href="<?php echo e($Setting['youtube']); ?>" class="youtube"><i class="fa fa-youtube"></i></a>
            <a target="_blank" href="<?php echo e($Setting['googleplus']); ?>" class="google-plus"><i class="fa fa-google-plus"></i></a>
           
            <?php if(Auth::check()): ?>
            <div class="dropdown">
                <a href="#" onclick="myFunction()" class="dropbtn"><i class="fa fa-user" aria-hidden="true"></i> <?php echo e(Auth::user()->username); ?></a>
                <div id="myAccount" class="account-content">
                    <a class="t-account" href="#"><i class="fa fa-info-circle" aria-hidden="true"></i> Tài khoản</a>
                    
                    <a class="t-account" href="<?php echo e(url('logout?back='.Request::fullUrl())); ?>"> <i class="fa fa-sign-out" aria-hidden="true"></i> Đăng xuất</a>
                </div>
            </div>
             <?php else: ?>
                <a href="<?php echo e(url('login')); ?>"  class="login-frontend"> Đăng nhập</a>
            <?php endif; ?>
        </div>

    </div>
</nav>

<div class="container-fluid header-logo">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-3 col-3 logo">
                <a href="<?php echo e(url('/')); ?>" class="custom-logo-link" rel="home" itemprop="url">
                    <img src="<?php echo e(asset($Setting['logo'])); ?>" class="custom-logo" alt="" itemprop="logo">
                </a>
            </div>
            <div class="col-md-9 col-sm-9 col-9 header-banner text-right">
                <a href="#">
                    <img src="<?php echo e(asset('homes/images/uploads/banner.png')); ?>" class="attachment-newspaper-x-wide-banner size-newspaper-x-wide-banner" alt="">
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Modal login and resgiter -->

<?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/homes/layouts/menu-top.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="content-header">
        <h1>
            <?php echo e(str_limit($post->title,60)); ?>

            <small><?php echo e(config('admin.edit')); ?></small>
        </h1>
        <!-- breadcrumb start -->
        <ol class="breadcrumb" style="margin-right: 30px;">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(config('admin.home')); ?></a></li>
            <li>
                <?php echo e($post->id); ?>

            </li>
            <li>
                <?php echo e(config('admin.edit')); ?>

            </li>
           
        </ol>

        <!-- breadcrumb end -->

    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo e(config('admin.edit')); ?></h3>
                        <div class="box-tools">
                            <div class="btn-group pull-right" style="margin-right: 5px">
                                <form action="<?php echo e(route('listposts.destroy',[ $post->id ])); ?>" method="post" onsubmit="return confirm('Bạn có chắc chắn muốn xóa?')">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" class="_method" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> <?php echo e(config('admin.delete')); ?></button>
                                </form>
                            </div>

                            <div class="btn-group pull-right" style="margin-right: 5px">
                                <a href="<?php echo e(route('listposts.index')); ?>" class="btn btn-sm btn-default" title="<?php echo e(config('admin.list')); ?>"><i class="fa fa-list"></i><span class="hidden-xs">&nbsp;<?php echo e(config('admin.list')); ?></span></a>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <div class="modal-body">
                        <div class="row box-body">
                            <!-- Custom Tabs -->
                            <div class="nav-tabs-custom">
                                <ul class="nav nav-tabs">
                                    <li class="active"><a href="#tab_1" data-toggle="tab"><i class="fa fa-bars"></i> Basic Field</a></li>
                                    <li><a href="#tab_2" data-toggle="tab"><i class="fa fa-clock-o"></i> Seo meta</a></li>
                                </ul>
                                <form action="<?php echo e(route('listposts.update',[$post->id])); ?>" method="POST" enctype="multipart/form-data" id="valiForm">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <input type="hidden" name="post_slug" value="<?php echo e($post->id); ?>" >
                                    <div class="tab-content">
                                        <div class="tab-pane active" id="tab_1">
                                            <div class="box-body">
                                                <div class="form-group">
                                                    <label for="title" class="control-label"><?php echo e(config('admin.title')); ?>*</label>
                                                    <label for="title" generated="true" class="error"></label>
                                                    <input type="text" name="title" value="<?php echo e($post->title); ?>" maxlength="255" class="form-control title" placeholder="<?php echo e(config('admin.title')); ?>" required>
                                                </div>
                                                    
                                                <div class="form-group">
                                                    <label for="slug" class="control-label"><?php echo e(config('admin.slug')); ?>*</label>
                                                    <label for="slug" generated="true" class="error"></label>
                                                    <input type="text" name="slug" data-id="<?php echo e($post->id); ?>" value="<?php echo e($post->slug); ?>" maxlength="255" class="form-control slug" placeholder="<?php echo e(config('admin.slug')); ?>" required>
                                                </div>

                                                <div class="form-group">
                                                    <label>Categories*</label>
                                                    <select class="form-control category" style="width: 100%;" name="category[]" multiple="multiple" data-placeholder="Categories" required >
                                                    <?php echo $categories; ?>

                                                    </select>
                                                </div>

                                                <div class="form-group">
                                                    <label for="status" class="control-label"><?php echo e(config('admin.status')); ?>:</label>
                                                    <input type="checkbox" <?php echo e(($post->status === 1) ? 'checked' : ''); ?> name="status" data-toggle="toggle" data-size="xs" data-onstyle="primary" data-offstyle="warning" class="edit-status" value="<?php echo e(($post->status === 1) ? 1 : 0); ?>">
                                                    
                                                </div>
                                                
                                                <div class="form-group">
                                                    <label for="thumbnail" class="control-label"><?php echo e(config('admin.image')); ?></label>
                                                    <?php if ($errors->has('thumbnail')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('thumbnail'); ?>
                                                        <label class="error"><?php echo e($message); ?></label>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                    <input type="file" class="avatar" name="thumbnail" data-initial-preview="<?php echo e(asset($post->thumbnail)); ?>" data-initial-caption="<?php echo e($post->thumbnail); ?>"/>
                                                </div>

                                                <div class="form-group">
                                                    <label for="description" class="control-label"><?php echo e(config('admin.description')); ?></label>
                                                    <textarea class="form-control" name="description" col="3" placeholder="Input <?php echo e(config('admin.description')); ?>"><?php echo e($post->description); ?></textarea>
                                                </div>
                                                
                                                <div class="form-group">
                                                    <label for="content" class="control-label"><?php echo e(config('admin.content')); ?></label>
                                                    <textarea class="form-control" id="_content" name="content" placeholder="Input <?php echo e(config('admin.content')); ?>"><?php echo e($post->content); ?></textarea>
                                                </div>
                                                
                                            </div>
                                            
                                        </div>
                                        <!-- /.tab-pane -->
                                        <div class="tab-pane" id="tab_2">
                                            <div class="col-sm-12">
                                                <label for="seo_title" class="control-label">seo_title</label>
                                                <div class="input-group mb-10">
                                                    <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                                                    <input type="text" name="seo_title" value="<?php echo e($post->seo_title); ?>" class="form-control seo_title" placeholder="tiêu đề seo">
                                                </div>
                                                <span class="help-block">
                                                    <i class="fa fa-info-circle"></i>&nbsp;sử dụng a-z and 0-9.
                                                </span>
                                            </div>
                                            <div class="col-sm-12">
                                                <label for="seo_description" class="control-label">Seo description</label>
                                                <div class="input-group mb-10">
                                                    <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                                                    <input type="text" name="seo_description" value="<?php echo e($post->seo_description); ?>" class="form-control seo_description" placeholder="seo <?php echo e(config('admin.description')); ?>">
                                                </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <label for="seo_keywords" class="control-label">Seo keywords</label>
                                                <div class="input-group mb-10">
                                                    <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                                                    <input type="text" name="seo_keywords" value="<?php echo e($post->seo_keywords); ?>" class="form-control seo_keywords" placeholder="seo keywords">
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- /.box-body -->
                                        <div class="box-footer">
                                            <div class="col-md-12">
                                                <div class="btn-group pull-right">
                                                    <button type="submit" class="btn btn-primary"><?php echo e(config('admin.submit')); ?></button>
                                                </div>
                                                <div class="btn-group pull-left">
                                                    <button type="reset" class="btn btn-warning"><?php echo e(config('admin.reset')); ?></button>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- /.box-footer -->
                                    </div>
                                </form>
                                <!-- /.tab-content -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <?php echo $__env->make('admins.posts.validate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/admins/posts/edit.blade.php ENDPATH**/ ?>
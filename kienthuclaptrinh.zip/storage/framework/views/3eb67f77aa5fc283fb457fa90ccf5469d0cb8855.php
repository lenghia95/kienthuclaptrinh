<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="content-header">
    <h1>
        <?php echo e($title); ?>

        <small><?php echo e(config('admin.list')); ?></small>
    </h1>
    <!-- breadcrumb start -->
    <ol class="breadcrumb" style="margin-right: 30px;">
        <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(config('admin.home')); ?></a></li>
        <li><?php echo e($title); ?></li>
    </ol>
    <!-- breadcrumb end -->
</section>

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <div class="pull-right">
                        <div class="btn-group pull-right" style="margin-right: 10px">
                            <a class="btn btn-sm btn-twitter" title="Export"><i class="fa fa-download"></i><span class="hidden-xs"> <?php echo e(config('admin.export')); ?></span></a>
                            <button type="button" class="btn btn-sm btn-twitter dropdown-toggle" data-toggle="dropdown">
                                <span class="caret"></span>
                                <span class="sr-only">Toggle Dropdown</span>
                            </button>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="" target="_blank">All</a></li>
                                <li><a href="" target="_blank">Current page</a></li>
                                <li><a href="" target="_blank" class="export-selected">Selected rows</a></li>
                            </ul>
                        </div>
                    </div>

                </div>
                <div class="box-header with-border hide" id="filter-box">
                    <form action="" class="form-horizontal" pjax-container="" method="get">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="box-body">
                                    <div class="fields-group">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label"> ID</label>
                                            <div class="col-sm-8">
                                                <div class="input-group input-group-sm">
                                                    <div class="input-group-addon">
                                                        <i class="fa fa-pencil"></i>
                                                    </div>
                                                    <input type="text" class="form-control id" placeholder="ID" name="id" value="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-md-2"></div>
                                    <div class="col-md-8">
                                        <div class="btn-group pull-left">
                                            <button class="btn btn-info submit btn-sm"><i class="fa fa-search"></i>&nbsp;&nbsp;<?php echo e(config('admin.search')); ?></button>
                                        </div>
                                        <div class="btn-group pull-left " style="margin-left: 10px;">
                                            <a href="" class="btn btn-default btn-sm"><i class="fa fa-undo"></i>&nbsp;&nbsp;<?php echo e(config('admin.reset')); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- /.box-header -->
                <table id="example" class="table table-hover table-striped table-bordered">
                    <thead>
                    <tr class="_table_title">
                        <th> </th>
                        <th>ID
                            <a class="fa fa-fw fa-sort" href=""></a>
                        </th>
                        <th><?php echo e(config('admin.name')); ?></th>
                        <th><?php echo e(config('admin.email')); ?></th>
                        <th><?php echo e(config('admin.status')); ?></th>
                        <th><?php echo e(config('admin.created_at')); ?></th>
                        <th><?php echo e(config('admin.action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="icheckbox_minimal-blue" aria-checked="false" aria-disabled="false" style="position: relative;">
                                    <input type="checkbox" class="grid-row-checkbox" data-id="1" style="position: absolute; opacity: 0;">
                                </div>
                            </td>
                            <td><?php echo e($contact->id); ?></td>
                            <td><?php echo e($contact->name); ?></td>
                            <td><?php echo e($contact->email); ?></td>
                            <td align="center">
                                    
                                <span data-key="<?php echo e($contact->id); ?>" data-status="<?php echo e($contact->status); ?>" class="_status status-contact  alert-<?php echo e(($contact->status == 1) ? 'success' : 'warning'); ?>"> <?php echo e(($contact->status == 1) ? 'Done' : 'Slacking'); ?> </span>
                            </td>
                            <td><?php echo e(date('d/m/Y', strtotime($contact->created_at) )); ?></td>
                            <td align="center">
                                <a href="<?php echo e(route('contacts.show',[ 'id' => $contact->id ])); ?>"><i class="fa fa-eye"></i></a>
                                <a href="javascript:void(0);" data-id="<?php echo e($contact->id); ?>" class="grid-row-delete"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            // ajax delete
            $('.grid-row-delete').unbind('click').click(function() {
                var id = $(this).data('id');
                swal({
                    title: "Bạn có chắc chắn muốn xóa ?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Xác nhận",
                    showLoaderOnConfirm: true,
                    cancelButtonText: "Đóng",
                    preConfirm: function() {
                        return new Promise(function(resolve) {
                            $.ajax({
                                method: 'POST',
                                url: "<?php echo e(url('/admin/ajax/contact_del')); ?>/"+ id,
                                data: {
                                    _method: 'PUT',
                                    _token: "<?php echo e(csrf_token()); ?>",
                                },
                                success: function(data) {
                                    $.pjax.reload('#pjax-container');
                                    resolve(data);
                                    toastr.success(data);
                                }
                            });
                        });
                    }
                }).then(function(result) {
                    var data = result.value;
                    if (typeof data === 'object') {
                        if (data.status) {
                            swal(data.message, '', 'Thành công');
                        } else {
                            swal(data.message, '', 'Lỗi');
                        }
                    }
                });
            });

            // // ajax status
            $(document).on('click', '.status-contact', function(){
                var id = $(this).data('key');
                var status = $(this).attr('data-status');
                if(status == 1){
                    $(this).removeClass('alert-success').addClass('alert-warning');
                    $(this).text('Slacking');
                    $(this).attr('data-status',0)
                }
                else if(status == 0){
                    $(this).text('Done');
                    $(this).removeClass('alert-warning').addClass('alert-success');
                    $(this).attr('data-status',1)
                }
                
                $.ajax({
                    url: "<?php echo e(url('/admin/ajax/contact_status')); ?>/" + id,
                    type: "POST",
                    data: {
                        "status": status,
                        _token: "<?php echo e(csrf_token()); ?>",
                        _method: 'PUT'
                    },
                    success: function (data) {
                        toastr.success(data);
                    }
                });
            });
            // $('.grid-switch-status').bootstrapSwitch({
            //     size:'mini',
            //     onText: 'ON',
            //     offText: 'OFF',
            //     onColor: 'primary',
            //     offColor: 'default',
            //     onSwitchChange: function(event, state){
            //         var status = $(this).val();
            //         $(this).val(state ? 'on' : 'off');
            //         var id = $(this).data('key');
            //         $.ajax({
            //             url: "<?php echo e(url('/admin/ajax/contact_status')); ?>/" + id,
            //             type: "POST",
            //             data: {
            //                 "status": status,
            //                 _token: "<?php echo e(csrf_token()); ?>",
            //                 _method: 'PUT'
            //             },
            //             success: function (data) {
            //                 toastr.success(data);
            //             }
            //         });
                    
            //     }
            // });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogger\resources\views/admins/contacts/index.blade.php ENDPATH**/ ?>
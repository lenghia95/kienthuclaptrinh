<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Admin</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

    <link rel="stylesheet" href="<?php echo e(asset('backends/AdminLTE/plugins/iCheck/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backends/AdminLTE/plugins/colorpicker/bootstrap-colorpicker.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backends/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backends/bootstrap-fileinput/css/fileinput.min.css?v=4.3.7')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backends/AdminLTE/plugins/select2/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backends/AdminLTE/plugins/ionslider/ion.rangeSlider.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backends/AdminLTE/plugins/ionslider/ion.rangeSlider.skinNice.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backends/bootstrap-switch/dist/css/bootstrap3/bootstrap-switch.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backends/fontawesome-iconpicker/dist/css/fontawesome-iconpicker.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backends/bootstrap-duallistbox/dist/bootstrap-duallistbox.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backends/AdminLTE/dist/css/skins/skin-blue.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backends/AdminLTE/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backends/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backends/laravel-admin/laravel-admin.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backends/nprogress/nprogress.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backends/sweetalert2/dist/sweetalert2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backends/nestable/nestable.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backends/toastr/build/toastr.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backends/bootstrap3-editable/css/bootstrap-editable.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backends/google-fonts/fonts.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backends/AdminLTE/dist/css/AdminLTE.min.css')); ?>">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">

    

    <script src="<?php echo e(asset('backends/AdminLTE/plugins/jQuery/jQuery-2.1.4.min.js')); ?>"></script>
    
    <!-- jquery.validate  -->
    <script src="<?php echo e(asset('backends/jquery-validation/jquery.validate.min.js')); ?>" type="text/javascript"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
    
    <script src="<?php echo e(asset('backends/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('link'); ?>
</head>
<?php $config = new App\Models\Config;?>
<body class="<?php echo e($config->getByKey('skin')); ?> <?php echo e($config->getByKey('layout')); ?> <?php if($config->getByKey('layout') == 'sidebar-mini'): ?> sidebar-collapse <?php endif; ?>" bsurl="<?php echo e(url('')); ?>" adminRoute="<?php echo e(config('laraadmin.adminRoute')); ?>">
<div class="wrapper">

    <?php echo $__env->make('admins.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('admins.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="content-wrapper" id="pjax-container">
        <div id="app">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    <?php echo $__env->make('admins.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<script>

    $(function() {
        $('.grid-row-checkbox').iCheck({
            checkboxClass: 'icheckbox_minimal-blue'
        }).on('ifChanged', function() {
            if (this.checked) {
                $(this).closest('tr').css('background-color', '#ffffd5');
            } else {
                $(this).closest('tr').css('background-color', '');
            }
        });

        var selectedRows = function() {
            var selected = [];
            $('.grid-row-checkbox:checked').each(function() {
                selected.push($(this).data('id'));
            });

            return selected;
        }

        $('.export-selected').click(function(e) {
            e.preventDefault();
            var rows = selectedRows().join(',');
            if (!rows) {
                return false;
            }
            var href = $(this).attr('href').replace('__rows__', rows);
            location.href = href;
        });

        $('.grid-refresh').on('click', function() {
            //$.pjax.reload('#pjax-container');
            toastr.success('<?php echo e(config('admin.refresh_succeeded')); ?>');
        });

        $('.filter-btn').click(function(e) {
            if ($('#filter-box').is(':visible')) {
                $('#filter-box').addClass('hide');
            } else {
                $('#filter-box').removeClass('hide');
            }
        });

        $('.grid-per-pager').on("change", function(e) {
            $.pjax({
                url: this.value,
                container: '#pjax-container'
            });
        });

    });

    $(function () {
        $("input.avatar").fileinput({"overwriteInitial":true,"initialPreviewAsData":true,"browseLabel":"Browse","showRemove":false,"showUpload":false,"deleteExtraData":{"avatar":"_file_del_","_file_del_":"","_token":"2EXIWpYuxecTOZhhEKr1oU0PEYYb6TMPfzhWyNiG","_method":"PUT"},"deleteUrl":"http:\/\/shopcart.local\/admin\/auth\/","allowedFileTypes":["image"]});
        $(".roles").select2({"allowClear":true,"placeholder":{"id":"","text":"Roles"}});
        $(".categories").select2({"allowClear":true,"placeholder":{"id":"","text":"Categories"}});
        $(".permissions").select2({"allowClear":true,"placeholder":{"id":"","text":"Permissions"}});
        $(".parent_id").select2({"allowClear":true,"placeholder":{"id":"","text":"Parent"}});
        $('.icon').iconpicker({placement:'bottomLeft'});
        $('.after-submit').iCheck({checkboxClass:'icheckbox_minimal-blue'}).on('ifChecked', function () {
            $('.after-submit').not(this).iCheck('uncheck');
        });
  
    });

    $(document).ready(function() {
        $('#example').DataTable();
        $('.sidebar-toggle').click(function(){
            $('body').toggleClass('sidebar-mini');
        });
    });

    function convertSlug(name){
        slug = name.toLowerCase();
        slug = slug.replace(/á|à|ả|ạ|ã|ă|ắ|ằ|ẳ|ẵ|ặ|â|ấ|ầ|ẩ|ẫ|ậ/gi, 'a');
        slug = slug.replace(/é|è|ẻ|ẽ|ẹ|ê|ế|ề|ể|ễ|ệ/gi, 'e');
        slug = slug.replace(/i|í|ì|ỉ|ĩ|ị/gi, 'i');
        slug = slug.replace(/ó|ò|ỏ|õ|ọ|ô|ố|ồ|ổ|ỗ|ộ|ơ|ớ|ờ|ở|ỡ|ợ/gi, 'o');
        slug = slug.replace(/ú|ù|ủ|ũ|ụ|ư|ứ|ừ|ử|ữ|ự/gi, 'u');
        slug = slug.replace(/ý|ỳ|ỷ|ỹ|ỵ/gi, 'y');
        slug = slug.replace(/đ/gi, 'd');
        //Xóa các ký tự đặt biệt
        slug = slug.replace(/\`|\~|\!|\@|\#|\||\$|\%|\^|\&|\*|\(|\)|\+|\=|\,|\.|\/|\?|\>|\<|\'|\"|\:|\;|_/gi, '');
        //Đổi khoảng trắng thành ký tự gạch ngang
        slug = slug.replace(/ /gi, "-");
        //Đổi nhiều ký tự gạch ngang liên tiếp thành 1 ký tự gạch ngang
        //Phòng trường hợp người nhập vào quá nhiều ký tự trắng
        slug = slug.replace(/\-\-\-\-\-/gi, '-');
        slug = slug.replace(/\-\-\-\-/gi, '-');
        slug = slug.replace(/\-\-\-/gi, '-');
        slug = slug.replace(/\-\-/gi, '-');
        //Xóa các ký tự gạch ngang ở đầu và cuối
        slug = '@' + slug + '@';
        slug = slug.replace(/\@\-|\-\@|\@/gi, '');
        return slug;
    }
</script>

<script src="<?php echo e(asset('backends/vendor/chartjs/dist/Chart.bundle.min.js')); ?>"></script>
<!-- REQUIRED JS SCRIPTS -->
<script src="<?php echo e(asset('backends/AdminLTE/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('backends/AdminLTE/plugins/slimScroll/jquery.slimscroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('backends/AdminLTE/dist/js/app.min.js')); ?>"></script>
<script src="<?php echo e(asset('backends/jquery-pjax/jquery.pjax.js')); ?>"></script>
<script src="<?php echo e(asset('backends/nprogress/nprogress.js')); ?>"></script>
<script src="<?php echo e(asset('backends/nestable/jquery.nestable.js')); ?>"></script>
<script src="<?php echo e(asset('backends/toastr/build/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('backends/bootstrap3-editable/js/bootstrap-editable.min.js')); ?>"></script>
<script src="<?php echo e(asset('backends/sweetalert2/dist/sweetalert2.min.js')); ?>"></script>
<script src="<?php echo e(asset('backends/laravel-admin/laravel-admin.js')); ?>"></script>
<script src="<?php echo e(asset('backends/AdminLTE/plugins/iCheck/icheck.min.js')); ?>"></script>
<script src="<?php echo e(asset('backends/AdminLTE/plugins/colorpicker/bootstrap-colorpicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('backends/AdminLTE/plugins/input-mask/jquery.inputmask.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('backends/moment/min/moment-with-locales.min.js')); ?>"></script>
<script src="<?php echo e(asset('backends/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('backends/bootstrap-fileinput/js/plugins/canvas-to-blob.min.js?v=4.3.7')); ?>"></script>
<script src="<?php echo e(asset('backends/bootstrap-fileinput/js/fileinput.min.js?v=4.3.7')); ?>"></script>
<script src="<?php echo e(asset('backends/AdminLTE/plugins/select2/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('backends/number-input/bootstrap-number-input.js')); ?>"></script>
<script src="<?php echo e(asset('backends/AdminLTE/plugins/iCheck/icheck.min.js')); ?>"></script>
<script src="<?php echo e(asset('backends/AdminLTE/plugins/ionslider/ion.rangeSlider.min.js')); ?>"></script>
<script src="<?php echo e(asset('backends/bootstrap-switch/dist/js/bootstrap-switch.min.js')); ?>"></script>
<script src="<?php echo e(asset('backends/fontawesome-iconpicker/dist/js/fontawesome-iconpicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('backends/bootstrap-duallistbox/dist/jquery.bootstrap-duallistbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('backends/packages/ckeditor/ckeditor.js')); ?>"></script>
<script src="<?php echo e(asset('backends/packages/ckeditor/adapters/jquery.js')); ?>"></script>
<?php echo $__env->yieldPushContent('script'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\blogger\resources\views/admins/layouts/app.blade.php ENDPATH**/ ?>
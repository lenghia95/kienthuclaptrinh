<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        &nbsp;&nbsp;&nbsp;&nbsp;

        <strong>Version</strong>&nbsp;&nbsp; 2.1.3

    </div>
    <!-- Default to the left -->
    <strong><a href="https://s-cart.org">Shop giày</a></strong> Free Open Source eCommerce for Business
</footer><?php /**PATH C:\xampp\htdocs\blogger\resources\views/admins/layouts/footer.blade.php ENDPATH**/ ?>
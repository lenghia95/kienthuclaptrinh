<div class="fakeimg p-1 mt-2">
    <div class="news-ticker" id="outer">
        <ul id ="tick">
            <?php $__currentLoopData = App\Models\Post::getPosts(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key < 10): ?>
              
                    <li>
                        <img width="30" height="30" src="<?php echo e(asset($post->thumbnail)); ?>" alt="">
                        <span class="badge badge-warning" style="color:#fff;"><?php echo e($post->name); ?></span>
                        <a href="<?php echo e(url('post/'.$post->slug)); ?>" >
                            <?php echo e($post->title); ?>

                        </a>
                    </li>
              
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <h5 class="title-ticker"><i class="fa fa-hand-o-right"></i> Mới nhất</h5>
    </div>
</div><?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/homes/layouts/stick.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo e(( isset($pagetitle) ) ? $pagetitle : 'Lỗi - Page 404'); ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <?php echo $__env->make('homes.layouts.link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<!-- header -->
<header>
    <?php echo $__env->make('homes.layouts.menu-top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>
<!-- header -->

<!-- main menu -->
    <?php echo $__env->make('homes.layouts.main-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- main menu -->

<!-- content -->
<div class="container p-0 wrapper">

    <div class="row small-row">

        <?php echo $__env->yieldContent('content'); ?>

    </div>
    
</div>

<!-- content -->

<!-- Footer -->
    <?php echo $__env->make('homes.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer -->
   <?php echo $__env->make('homes.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/homes/layouts/app.blade.php ENDPATH**/ ?>
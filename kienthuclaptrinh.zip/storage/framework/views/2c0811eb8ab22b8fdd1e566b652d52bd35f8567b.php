<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar" style="height: auto;">

        <!-- Sidebar user panel (optional) -->
        <?php if( Auth::check()): ?>
            <div class="user-panel">
                <div class="pull-left image">
                    <img src="<?php echo e(asset(Auth::user()->avatar)); ?>" class="img-circle" alt="<?php echo e(Auth::user()->fullname); ?>" />
                </div>
                <div class="pull-left info">
                    <p><?php echo e(Auth::user()->fullname); ?></p>
                    <!-- Status -->
                    <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
                </div>
            </div>
        <?php endif; ?>

        <?php if(App\Models\Config::getByKey('sidebar_search')): ?>
            <form action="#" method="get" class="sidebar-form">
                <div class="input-group">
                    <input type="text" name="q" class="form-control" placeholder="Search..."/>
                    <span class="input-group-btn">
                <button type='submit' name='search' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i></button>
              </span>
                </div>
            </form>
        <?php endif; ?>
        <!-- /.search form -->

        <!-- Sidebar Menu -->
        <ul class="sidebar-menu">
            <li class="header">Menu</li>
            <?php $menus = new App\Models\Menu ?>
            <?php echo $menus->menuSidebar(); ?>

        </ul>
        <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>

<?php /**PATH C:\xampp\htdocs\blogger\resources\views/admins/layouts/sidebar.blade.php ENDPATH**/ ?>
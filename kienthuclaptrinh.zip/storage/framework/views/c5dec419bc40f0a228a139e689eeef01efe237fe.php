<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td>
        <div class="icheckbox_minimal-blue">
            <input type="checkbox" class="grid-row-checkbox" data-id="1" style="position: absolute; opacity: 0;">
        </div>
    </td>
    <td><?php echo e($post->id); ?></td>
    <td><?php echo e($post->title); ?></td>
    <td>
        <img width="100" src="<?php echo e(asset($post->thumbnail)); ?>" class="img-thumbnail" title="<?php echo e($post->title); ?>" />
    </td>
    <td>
        <?php $Cat = new App\Models\PostCategory ?>
        <?php $__currentLoopData = $Cat->getCatsByPostId($post->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="btn btn-info btn-xs"> <?php echo e($cat->name); ?> </span><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </td>
    <td>
        <a class="btn btn-warning btn-xs"><?php echo e($post->uName); ?></a>
    </td>
    <td>
        <input type="checkbox" data-key="<?php echo e($post->id); ?>" class="grid-switch-status" <?php echo e(($post->status == 1) ? 'checked' : ''); ?> data-toggle="toggle" data-size="mini">
    </td>
    <td><?php echo e(date('d/m/Y', strtotime($post->created_at))); ?></td>
    <td align="center">
        <a href="<?php echo e(route('listposts.show',[$post->id])); ?>"><i class="fa fa-eye"></i></a>
        <a href="<?php echo e(route('listposts.edit',['id' => $post->id])); ?>"><i class="fa fa-edit"></i></a>
        <a href="javascript:void(0)" data-id="<?php echo e($post->id); ?>" class="grid-row-delete">
            <i class="fa fa-trash"></i>
        </a>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
    $(function() {

        $('.grid-row-checkbox').iCheck({
            checkboxClass: 'icheckbox_minimal-blue'
        }).on('ifChanged', function() {
            if (this.checked) {
                $(this).closest('tr').css('background-color', '#ffffd5');
            } else {
                $(this).closest('tr').css('background-color', '');
            }
        });

    });
    
    $(document).ready(function () {
        // ajax status
        $('.grid-switch-status').bootstrapSwitch({
            size:'mini',
            onText: 'ON',
            offText: 'OFF',
            onColor: 'primary',
            offColor: 'default',
            onSwitchChange: function(event, state){
                $(this).val(state ? 'on' : 'off');
                var id = $(this).data('key');
                $.ajax({
                    url: "<?php echo e(url('/admin/ajax/status_posts')); ?>/" + id,
                    type: "POST",
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>",
                        _method: 'PUT'
                    },
                    success: function (data) {
                        toastr.success(data);
                    }
                });
            }
        });
    });
     
</script><?php /**PATH C:\xampp\htdocs\blogger\resources\views/admins/posts/search.blade.php ENDPATH**/ ?>
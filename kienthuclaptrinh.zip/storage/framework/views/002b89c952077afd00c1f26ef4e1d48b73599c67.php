<nav class="navbar navbar-expand-sm bg-primary navbar-dark sticky-top" id="main_navbar">
    <div class="container pl-0" style="position: relative;">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse shows" id="navbarSupportedContent" >
               
            <ul class="navbar-nav mr-auto navbar-menu">
                <?php $__currentLoopData = App\Models\Category::getCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item main-menu">
                        <a class="nav-link nav-main" href="<?php echo e(url('category/'.$category->slug)); ?>"><?php echo e($category->name); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                

            </ul>
           
        </div>
    </div>
</nav>



<div class="container">
    <div class="row small-row">
        <div class="col-md-12 p-0">

            <?php echo $__env->make('homes.layouts.stick', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>

        <div class="col-md-12 p-0 mt-4">
            <form action="<?php echo e(url('/search')); ?>" method="get">
                <div class="input-group mb-3">
                    <input type="search"  name="s" placeholder="Gõ từ khóa và Enter...!">
                    <input type="submit" class="d-none" />
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/homes/layouts/main-menu.blade.php ENDPATH**/ ?>
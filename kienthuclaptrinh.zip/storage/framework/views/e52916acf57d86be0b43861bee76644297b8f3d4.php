<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="content-header">
        <h1>
            <?php echo e($slide->key); ?>

            <small><?php echo e(config('admin.edit')); ?></small>
        </h1>
        <!-- breadcrumb start -->
        <ol class="breadcrumb" style="margin-right: 30px;">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(config('admin.home')); ?></a></li>
            <li>
                <?php echo e($slide->id); ?>

            </li>
            <li>
                <?php echo e(config('admin.edit')); ?>

            </li>
        </ol>

        <!-- breadcrumb end -->

    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo e(config('admin.edit')); ?></h3>
                        <div class="box-tools">
                            <div class="btn-group pull-right" style="margin-right: 5px">
                                <form action="<?php echo e(route('sliders.destroy',['id'=>$slide->id])); ?>" method="post" onsubmit="return confirm('Bạn có chắc chắn muốn xóa?')">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" class="_method" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> <?php echo e(config('admin.delete')); ?></button>
                                </form>
                            </div>

                            <div class="btn-group pull-right" style="margin-right: 5px">
                                <a href="<?php echo e(route('sliders.index')); ?>" class="btn btn-sm btn-default" title="<?php echo e(config('admin.list')); ?>"><i class="fa fa-list"></i><span class="hidden-xs">&nbsp;<?php echo e(config('admin.list')); ?></span></a>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    
                    <form action="<?php echo e(route('sliders.update',[ 'id' => $slide->id ])); ?>" method="post" class="form-horizontal" id="valiForm">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" class="_method" name="_method" value="PUT">
                        <input type="hidden" name="slider_id" value="<?php echo e($slide->id); ?>"/>
                        <div class="box-body">
                            <div class="fields-group">
                                <div class="form-group">
                                    <label for="key" class="col-sm-2  control-label"><?php echo e(config('admin.key')); ?></label>
                                    <div class="col-sm-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                                            <input type="text" name="key" data-id="<?php echo e($slide->id); ?>" value="<?php echo e($slide->key); ?>" class="form-control title" placeholder="<?php echo e(config('admin.slide')); ?>" required />
                                        </div>
                                        <?php if ($errors->has('key')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('key'); ?>
                                            <label class="error"><?php echo e($message); ?></label>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        <label for="key" generated="true" class="error"></label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="status" class="col-sm-2 text-right">Status</label>
                                    <div class="col-sm-8">
                                        <input type="checkbox" <?php echo e(($slide->status === 1) ? 'checked' : ''); ?> data-toggle="toggle" data-size="xs" data-onstyle="primary" data-offstyle="warning" class="edit-status" value="<?php echo e(($slide->status === 1) ? 1 : 0); ?>">
                                        <input type="hidden" name="status" value="<?php echo e(($slide->status === 1) ? 1 : 0); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <div class="col-md-2">
                            </div>
                            <div class="col-md-8">
                                <div class="btn-group pull-right">
                                    <button type="submit" class="btn btn-primary"><?php echo e(config('admin.submit')); ?></button>
                                </div>
                                <div class="btn-group pull-left">
                                    <button type="reset" class="btn btn-warning"><?php echo e(config('admin.reset')); ?></button>
                                </div>
                            </div>
                        </div>

                        <!-- /.box-footer -->
                    </form>
                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <?php echo $__env->make('admins.sliders.validate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/admins/sliders/edit.blade.php ENDPATH**/ ?>
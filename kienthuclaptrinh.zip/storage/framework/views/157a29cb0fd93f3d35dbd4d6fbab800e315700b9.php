<?php $__env->startSection('roles'); ?>
    <form action="<?php echo e(route('roles.update',['id'=>$role->id])); ?>" class="_form_bk mt-10 ml-10" method="POST" id="valiForm">
        <input type="hidden" class="_method" name="_method" value="PUT">
        <input type="hidden" name="role_name" value="<?php echo e($role->id); ?>">
        <?php echo csrf_field(); ?>
        <h3 class="modal-title ml-15" id="modalLabel"><?php echo e(config('admin.edit')); ?> <?php echo e(config('admin.role')); ?></h3>
        <div class="modal-body">
            <div class="fields-group row">
                <div class="form-group">
                    <div class="col-sm-12">
                        <label for="name" class="control-label"><?php echo e(config('admin.name')); ?>*</label>
                        <label for="_name" generated="true" class="error"></label>
                        <div class="input-group mb-10">
                            <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                            <input type="text" name="name" data-id="<?php echo e($role->id); ?>" id="_name"value="<?php echo e($role->name); ?>" class="form-control name" placeholder="<?php echo e(config('admin.name')); ?>" required>
                        </div>
                        <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                            <label for="name" generated="true" class="error"><?php echo e($message); ?></label>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-12">
                        <label for="slug" class="control-label">Display Name*</label>
                        <label for="_slug" generated="true" class="error"></label>
                        <div class="input-group mb-10">
                            <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                            <input type="text"  name="display_name" value="<?php echo e($role->display_name); ?>" class="form-control" placeholder="Display Name" required>
                        </div>
                        <?php if ($errors->has('display_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('display_name'); ?>
                            <label for="name" generated="true" class="error"><?php echo e($message); ?></label>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-12">
                        <label for="description" class="control-label"><?php echo e(config('admin.description')); ?>*</label>
                        <label for="description" generated="true" class="error"></label>
                        <div class="input-group mb-10">
                            <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                            <input type="text" name="description" value="<?php echo e($role->description); ?>" class="form-control description" placeholder="<?php echo e(config('admin.description')); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary"><?php echo e(config('admin.update')); ?></button>
            <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-danger"><?php echo e(config('admin.close')); ?></a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.roles.widgets.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/admins/roles/edit.blade.php ENDPATH**/ ?>
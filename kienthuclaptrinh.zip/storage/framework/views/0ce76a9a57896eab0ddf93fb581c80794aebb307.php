<style>
    .form-group {
        display: -webkit-box;
    }
</style>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="content-header">
        <h1>
            <?php echo e($user->username); ?>

            <small><?php echo e(config('admin.show')); ?></small>
        </h1>
        <!-- breadcrumb start -->
        <ol class="breadcrumb" style="margin-right: 30px;">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(config('admin.home')); ?></a></li>
            <li>
                <?php echo e($user->username); ?>

            </li>
            <li>
                <?php echo e($user->id); ?>

            </li>
            <li>
                <?php echo e(config('admin.show')); ?>

            </li>
        </ol>

        <!-- breadcrumb end -->
        
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo e(config('admin.show')); ?></h3>
                        <div class="box-tools">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create')): ?>
                                <div class="btn-group pull-right" style="margin-right: 5px">
                                    <form action="<?php echo e(route('users.destroy',['id'=>$user->id])); ?>" method="post" onsubmit="return confirm('Bạn có chắc chắn muốn xóa?')">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" class="_method" name="_method" value="DELETE">
                                        <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> <?php echo e(config('admin.delete')); ?></button>
                                    </form>
                                </div>
                                <div class="btn-group pull-right" style="margin-right: 5px">
                                    <a href="#" data-toggle="modal" data-target="#change_password" class="btn btn-sm btn-primary" title="<?php echo e(config('admin.change_password')); ?>">
                                        <i class="fa fa-edit"></i>
                                        <span class="hidden-xs">&nbsp;Change Pass</span>
                                    </a>
                                </div>
                            <?php endif; ?>
                            <div class="btn-group pull-right" style="margin-right: 5px">
                                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-sm btn-default" title="<?php echo e(config('admin.list')); ?>"><i class="fa fa-list"></i><span class="hidden-xs">&nbsp;<?php echo e(config('admin.list')); ?></span></a>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    
                        <div class="box-body">
                            <div class="fields-group">
                                <div class="form-group">
                                    <label for="email" class="col-sm-2  control-label text-right"><?php echo e(config('admin.email')); ?>:</label>
                                    <div class="col-sm-8">
                                        <div class="form-control"> <?php echo e($user->email); ?></div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="name" class="col-sm-2  control-label text-right"><?php echo e(config('admin.fullname')); ?>:</label>
                                    <div class="col-sm-8">
                                        <div class="form-control"> <?php echo e(( isset($user->fullname) ) ? $user->fullname : 'Chưa cập nhập'); ?></div>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label for="address" class="col-sm-2  control-label text-right">Address;</label>
                                    <div class="col-sm-8">
                                            <div class="form-control "> <?php echo e(( isset($user->address) ) ? $user->address : 'Chưa cập nhập'); ?></div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="phone" class="col-sm-2  control-label text-right"><?php echo e(config('admin.phone')); ?>:</label>
                                    <div class="col-sm-8">
                                       <div class="form-control"> <?php echo e(( isset($user->phone) ) ? $user->phone : 'Chưa cập nhập'); ?></div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="avatar" class="col-sm-2  control-label text-right"><?php echo e(config('admin.image')); ?>:</label>
                                    <div class="col-sm-8">
                                        <img width="300" src="<?php echo e(asset($user->avatar)); ?>" class="img-thumbnail" alt="">
                                        
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="phone" class="col-sm-2 control-label text-right"><?php echo e(config('admin.status')); ?>:</label>
                                    <div class="col-sm-8">
                                        <span class="label label-<?php echo e(($user->status == 1) ? 'success' : 'warning'); ?>"> <?php echo e(($user->status == 1) ? 'Đã duyệt' : 'Chưa duyệt'); ?></span>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                        <!-- /.box-body -->
                   
                </div>
            </div>
        </div>
       
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/admins/users/show.blade.php ENDPATH**/ ?>
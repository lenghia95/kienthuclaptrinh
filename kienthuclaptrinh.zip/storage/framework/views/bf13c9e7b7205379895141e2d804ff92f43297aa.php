<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="content-header">
    <h1>
        <?php echo e($title); ?>

        <small><?php echo e(config('admin.list')); ?></small>
    </h1>
    <!-- breadcrumb start -->
    <ol class="breadcrumb" style="margin-right: 30px;">
        <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(config('admin.home')); ?></a></li>
        <li><?php echo e($title); ?></li>
    </ol>
    <!-- breadcrumb end -->
</section>

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="pull-right">
                        <a href="" class="btn btn-success" data-toggle="modal" data-target="#flipFlop"> <i class="fa fa-save"></i> <?php echo e(config('admin.new')); ?></a>
                    </div>
                    <!-- The modal -->
                    <div class="modal fade" id="flipFlop" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true" >
                        <div class="modal-dialog" role="document" >
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <h4 class="modal-title" id="modalLabel">Add Sliders</h4>
                                </div>
                                <form action="<?php echo e(route('sliders.store')); ?>" method="POST" id="valiForm">
                                    <?php echo csrf_field(); ?>
                                    <div class="box-body">
                                        <div class="fields-group">
                                            <div class="col-sm-12">
                                                <label for="key" class="control-label"><?php echo e(config('admin.key')); ?>*</label>
                                                <label for="key" generated="true" class="error"></label>
                                                <div class="input-group mb-10">
                                                    <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                                                    <input type="text" name="key" value="<?php echo e(old('key')); ?>" maxlength="255" class="form-control key" placeholder="<?php echo e(config('admin.key')); ?>" required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.box-body -->
                                    <div class="box-footer">
                                        <div class="col-md-12">
                                            <div class="btn-group pull-right">
                                                <button type="submit" class="btn btn-primary"><?php echo e(config('admin.submit')); ?></button>
                                            </div>
                                            <div class="btn-group pull-right" style="margin-right:10px">
                                                <button type="reset" class="btn btn-warning"><?php echo e(config('admin.reset')); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.box-footer -->
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- /.box-header -->
                <table id="example" class="table table-hover table-striped table-bordered">
                    <thead>
                    <tr class="_table_title">
                        <th> </th>
                        <th>ID
                            <a class="fa fa-fw fa-sort" href=""></a>
                        </th>
                        <th><?php echo e(config('admin.key')); ?></th>
                        <th><?php echo e(config('admin.status')); ?></th>
                        <th><?php echo e(config('admin.action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="icheckbox_minimal-blue" aria-checked="false" aria-disabled="false" style="position: relative;">
                                    <input type="checkbox" class="grid-row-checkbox" data-id="1" style="position: absolute; opacity: 0;">
                                </div>
                            </td>
                            <td><?php echo e($slider->id); ?></td>
                            <td><?php echo e($slider->key); ?></td>
                            <td>
                                <input type="checkbox" <?php echo e(($slider->status === 1) ? 'checked' : ''); ?> class="grid-switch-status" data-key="<?php echo e($slider->id); ?>" value="<?php echo e(($slider->status === 1) ? 'on' : 'off'); ?>">
                            </td>
                            <td align="center">
                                <a href="<?php echo e(route('sliders.edit',[ 'id' => $slider->id ])); ?>"><i class="fa fa-edit"></i></a>
                                <a href="javascript:void(0);" data-id="<?php echo e($slider->id); ?>" class="grid-row-delete"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            // ajax delete
            $('.grid-row-delete').unbind('click').click(function() {
                var id = $(this).data('id');
                swal({
                    title: "Bạn có chắc chắn muốn xóa ?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Xác nhận",
                    showLoaderOnConfirm: true,
                    cancelButtonText: "Đóng",
                    preConfirm: function() {
                        return new Promise(function(resolve) {
                            $.ajax({
                                method: 'POST',
                                url: "<?php echo e(url('/admin/ajax/slider_del')); ?>/"+ id,
                                data: {
                                    _method: 'PUT',
                                    _token: "<?php echo e(csrf_token()); ?>",
                                },
                                success: function(data) {
                                    $.pjax.reload('#pjax-container');
                                    resolve(data);
                                    toastr.success(data);
                                }
                            });
                        });
                    }
                }).then(function(result) {
                    var data = result.value;
                    if (typeof data === 'object') {
                        if (data.status) {
                            swal(data.message, '', 'Thành công');
                        } else {
                            swal(data.message, '', 'Lỗi');
                        }
                    }
                });
            });

            // ajax status
            $('.grid-switch-status').bootstrapSwitch({
                size:'mini',
                onText: 'ON',
                offText: 'OFF',
                onColor: 'primary',
                offColor: 'default',
                onSwitchChange: function(event, state){
                    var status = $(this).val();
                    $(this).val(state ? 'on' : 'off');
                    var id = $(this).data('key');
                    $.ajax({
                        url: "<?php echo e(url('/admin/ajax/slider_status')); ?>/" + id,
                        type: "POST",
                        data: {
                            "status": status,
                            _token: "<?php echo e(csrf_token()); ?>",
                            _method: 'PUT'
                        },
                        success: function (data) {
                            toastr.success(data);
                        }
                    });
                    
                }
            });

            
        });
    </script>
    <?php echo $__env->make('admins.sliders.validate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogger\resources\views/admins/sliders/index.blade.php ENDPATH**/ ?>
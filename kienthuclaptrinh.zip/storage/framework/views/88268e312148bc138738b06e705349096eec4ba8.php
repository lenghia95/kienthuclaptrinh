<?php $__env->startSection('content'); ?>
    <!-- Breadcrumb -->
    <div class="col-sm-8 col-sm-12 col-lg-8">
        <div class="fakeimg p-2 mt-2">
            <div class="news-ticker" >
                <ul>
                    <li>
                        <span>
                            <a href="<?php echo e(url('/')); ?>" >
                                <span>Trang chủ</span>
                            </a>
                        </span>
                    </li>
                    <li>
                        <span>
                            <i class="fa fa-angle-double-right"></i>
                            <span class="title">Đăng nhập</span>
                        </span>
                    </li>
                </ul>
            </div>
        </div>

        <?php if(session('msg')): ?>
            <br><div class="alert alert-success"><?php echo e(session('msg')); ?></div>
        <?php endif; ?>
        <?php if(session('failed')): ?>
            <br><div class="alert alert-danger"><?php echo e(session('failed')); ?></div>
        <?php endif; ?>
        
        <div class="fakeimg mt-2 p-2">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-center" id="loginOrRegisterModalLabel">Đăng nhập hoặc đăng ký để khám phá thêm!</h5>
                   
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12 col-lg-6">
                            <h2>Đăng nhập</h2>
                            <form method="POST" action="<?php echo e(url('login')); ?>" id="loginForm" accept-charset="UTF-8">
                                <?php echo csrf_field(); ?>
                                <!-- Email -->
                                <div class="form-group">
                                    <input class="form-control form-contro" value="<?php echo e(old('email')); ?>" required="" placeholder="E-Mail Address" name="email" type="email">
                                    <small class="text-danger"></small>
                                </div>
                                <!-- Password -->
                                <div class="form-group">
                                    <input class="form-control" required="required" placeholder="Mật khẩu" name="password" type="password" value="">
                                    <small class="text-danger"></small>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-sm btn-info">
                                        Đăng nhập
                                    </button>
                                    <a class="btn btn-sm btn-link" href="https://chungnguyen.xyz/password/reset">
                            Quên mật khẩu rồi
                            </a>
                                </div>
                            </form>
                        </div>
                        <div class="col-12 col-lg-6">
                            <form method="POST" action="<?php echo e(url('register')); ?>" id="registerForm" accept-charset="UTF-8">
                                <?php echo csrf_field(); ?>
                                
                                <h2>hoặc Đăng ký</h2>
                                <!-- Name -->
                                <div class="form-group">
                                    <input class="form-control" value="<?php echo e(old('username')); ?>" required="required" placeholder="Tên" name="username" type="text">
                                    <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
                                        <label id="username-error" class="error" for="username"><?php echo e($message); ?></label>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    <small class="text-danger"></small>
                                </div>
                                <!-- Email -->
                                <div class="form-group">
                                    <input class="form-control" id="register_email" required value="<?php echo e(old('email')); ?>" placeholder="E-Mail Address" name="email" type="email" />
                                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                        <label id="email-error" class="error" for="email"><?php echo e($message); ?></label>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    <small class="text-danger"></small>
                                </div>
                                <!-- Password -->
                                <div class="form-group">
                                    <input class="form-control" required="required" id="password" placeholder="Mật khẩu" name="password" type="password" value="">
                                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                        <label id="password-error" class="error" for="password"><?php echo e($message); ?></label>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    <small class="text-danger"></small>
                                </div>
                                <!-- Confirm Password -->
                                <div class="form-group">
                                    <input id="password-confirm" type="password" class="form-control" name="repassword" placeholder="Xác nhận mật khẩu" >
                                    <?php if ($errors->has('repassword')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('repassword'); ?>
                                        <label id="repassword-error" class="error" for="repassword"><?php echo e($message); ?></label>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <!-- submit -->
                                <div class="form-group">
                                    <button type="submit" class="btn btn-sm btn-info">
                                        Đăng ký
                                    </button>
                                </div>
                            </form>
                        </div>
                        <div class="col text-center">
                            <a href="<?php echo e(route('facebook.login')); ?>" class="fb btn social-facebook"><i class="fa fa-facebook fa-fw"></i> Login with Facebook</a>
                            <a href="javascript:void(0)" class="twitter btn social-twitter"><i class="fa fa-twitter fa-fw"></i> Login with Twitter</a>
                            <a href="javascript:void(0)" class="google btn social-google"><i class="fa fa-google fa-fw"></i> Login with Google+</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- main-content -->
    </div>
    
    <div class="col-sm-4 col-sm-12 col-lg-4 sticky sidebar">
        <?php echo $__env->make('homes.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('homes.layouts.fanpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('homes.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/auth/login.blade.php ENDPATH**/ ?>
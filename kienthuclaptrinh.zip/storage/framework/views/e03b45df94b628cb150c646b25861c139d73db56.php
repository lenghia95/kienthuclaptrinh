<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="fakeimg p-2 mt-2">
            <h3><?php echo e($page->title); ?></h3>
            <?php echo $page->content; ?>

        </div>
        <?php if(app('request')->input('s')): ?>
            <div class="fakeimg p-2 mt-2">
                <div class="news-ticker" >
                    <ul>
                        <li>
                            <span>
                                <a href="<?php echo e(url('/')); ?>" >
                                    <span>Trang chủ</span>
                                </a>
                            </span>
                        </li>
                        <li>
                            <span>
                                <i class="fa fa-angle-double-right"></i>
                                <span class="title">Tìm kiếm</span>
                            </span>
                        </li>
                        <li>
                            <span>
                                <i class="fa fa-angle-double-right"></i>
                                <span class="title">Kết quả tìm kiếm cho từ khóa: 
                                    <b style="color:red">"<?php echo e(app('request')->input('s')); ?>"</b>
                                    - Tìm thấy :<span> <?php echo e($posts->total()); ?> </span>
                                </span>
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
        <?php else: ?> 
            <div class="fakeimg mt-2">
                <div class="widget-head">
                    <h3 class="widget-title text-light p-2">Bài viết mới</h3>
                </div>
            </div>
        <?php endif; ?>
        
        <div class="fakeimg p-2 mt-2">
            <!--  -->
            <div class="row">

                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-4 post-home">
                        <a href="<?php echo e(url('post/'.$post->slug)); ?>">
                            <img src="<?php echo e(asset($post->thumbnail)); ?>" class="img-thumbnail img-responsive margin" style="width:100%" alt="Image" />
                        </a>
                        <h5 class="mt-1"><a href="<?php echo e(url('post/'.$post->slug)); ?>"><?php echo e(str_limit($post->title,100)); ?></a></h5>
                        <div class="mom-post-meta bp-meta">
                            <span class="author vcard">Đăng bởi: <?php echo e($post->uName); ?></span>
                            <span>Ngày: 
                                <time class="updated"><?php echo e(date('d/m/Y',strtotime($post->created_at))); ?></time>
                                - <i class="fa fa-eye"> <?php echo e($post->views); ?> </i>
                                - <i class="fa fa-comments"> <?php echo e($post->comments->count()); ?> </i>
                            </span>
                        </div>
                        <p><?php echo str_limit($post->description,100); ?></p>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
            <div class="col-md-12">
                <?php echo e($posts->appends(Request::except('page'))->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('homes.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/homes/index.blade.php ENDPATH**/ ?>
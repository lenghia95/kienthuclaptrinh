<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form class="well form-horizontal" action="<?php echo e(url('/contact')); ?>" method="post" id="contact_form">
        <?php echo e(csrf_field()); ?>

         <fieldset>
             <!-- Form Name -->
             <legend>Liên hệ cho tôi</legend>
             <!-- Text input-->
             <!-- Success message -->
             <?php if(Session::has('msg')): ?>
                 <div class="alert alert-success" role="alert" id="success_message">Thành công 
                     <i class="glyphicon glyphicon-thumbs-up"></i> 
                     <?php echo e(Session::get('msg')); ?>

                 </div>
             <?php endif; ?>
             <div class="form-group">
                 <label class="col-md-2 control-label">Họ và tên</label>
                 <div class="col-md-10 inputGroupContainer">
                     <div class="input-group">
                         <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                         <input name="name" value="<?php echo e(old('name')); ?>" placeholder="Họ và tên" class="form-control" type="text" required>
                     </div>
                     <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <span style="color:#c23527;font-style:italic"><?php echo e($mes); ?></span><br>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </div>
                 
             </div>
             <!-- Text input-->
             <div class="form-group">
                 <label class="col-md-2 control-label">E-Mail</label>
                 <div class="col-md-10 inputGroupContainer">
                     <div class="input-group">
                         <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
                         <input name="email" value="<?php echo e(old('email')); ?>" placeholder="Địa chỉ E-Mail" class="form-control" type="text" required>
                     </div>
                     <?php $__currentLoopData = $errors->get('email'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <span style="color:#c23527;font-style:italic"><?php echo e($mes); ?></span><br>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </div>
             </div>
             <!-- Text input-->
             <div class="form-group">
                 <label class="col-md-2 control-label">Số điện thoại</label>
                 <div class="col-md-10 inputGroupContainer">
                     <div class="input-group">
                         <span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span>
                         <input name="phone" value="<?php echo e(old('phone')); ?>" placeholder="(+84)827-460-579" class="form-control" type="number" required>
                     </div>
                     <?php $__currentLoopData = $errors->get('phone'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <span style="color:#c23527;font-style:italic"><?php echo e($mes); ?></span><br>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </div>
             </div>
             
             <div class="form-group">
                 <label class="col-md-2 control-label">Nội dung</label>
                 <div class="col-md-10 inputGroupContainer">
                     <div class="input-group">
                         <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
                         <textarea class="form-control" name="content" placeholder="Nội dung liên hệ" required></textarea>
                     </div>
                     <?php $__currentLoopData = $errors->get('content'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <span style="color:#c23527;font-style:italic"><?php echo e($mes); ?></span>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </div>
             </div>
            
             <!-- Button -->
             <div class="form-group">
                 <label class="col-md-2 control-label"></label>
                 <div class="col-md-10">
                     <button type="submit" class="btn btn-warning">Gửi <span class="glyphicon glyphicon-send"></span></button>
                 </div>
             </div>
     
         </fieldset>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\blogger\resources\views/homes/index.blade.php ENDPATH**/ ?>
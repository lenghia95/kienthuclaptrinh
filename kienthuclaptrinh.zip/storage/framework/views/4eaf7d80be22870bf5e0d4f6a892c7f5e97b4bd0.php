<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <!-- succeeded -->
        <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- succeeded -->
        <h1>
            <?php echo e($title); ?>

            <small><?php echo e(config('admin.list')); ?></small>
        </h1>
        <!-- breadcrumb start -->
        <ol class="breadcrumb" style="margin-right: 30px;">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(config('admin.home')); ?></a></li>
            <li><?php echo e($title); ?></li>
        </ol>
        <!-- breadcrumb end -->
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <!-- /.box-header -->
                    <div class="row">
                        <div class="col-md-4">
                            <?php echo $__env->yieldContent('menulist'); ?>
                        </div>

                        <div class="col-md-8">
                            <div class="form-group">
                                <div class="mb-10 mt-10 mr-10">
                                    <label for="parent" class="control-label">Chọn Menu Group*</label>
                                    <select class="form-control parent_id select2-hidden-accessible" onchange="if (this.value) window.location.href='<?php echo e(url('admin/menulists?group=')); ?>'+this.value" style="width: 100%;" name="menugroup" data-value="" tabindex="-1" aria-hidden="true">
                                       <?php $menuGroups = new App\Models\Menugroup; ?>
                                        <?php $__currentLoopData = $menuGroups->getMenugroups(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menugroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <option value="<?php echo e($menugroup->id); ?>" 
                                                <?php if(isset($menuList->menugroup) && $menuList->menugroup == $menugroup->id): ?> selected="selected" <?php endif; ?> 
                                                <?php if(app('request')->input('group') == $menugroup->id ): ?>selected="selected"<?php endif; ?>
                                                >
                                                <?php echo e($menugroup->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <table class="table table-hover table-striped table-bordered">
                                <thead>
                                <tr class="_table_title">
                                    <th> </th>
                                    <th>ID
                                        <a class="fa fa-fw fa-sort" href=""></a>
                                    </th>
                                    <th><?php echo e(config('admin.name')); ?></th>
                                    <th><?php echo e(config('admin.url')); ?></th>
                                    <th><?php echo e(config('admin.status')); ?></th>
                                    <th><?php echo e(config('admin.action')); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php echo $menuLists; ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $("#valiMenulist").validate({
                rules: {
                    url: {
                        remote: {
                            url: "<?php echo e(url('/admin/ajax/unique_url')); ?>",
                            type: "get",
                            data: {
                                url: function () {
                                    return $("input[name='url']").val();
                                },
                                id: function () {
                                    return $("input[name='url']").attr('data-id');
                                },
                            },
                            async:false,
                            dataFilter: function (data) {
                                var json = JSON.parse(data);
                                if (json.msg == "true") {
                                    return "\"" + "This value exists in database." + "\"";
                                } else {
                                    return 'true';
                                }
                            }
                        },
                    },
                },
            });

            //ajax delete
            $('.grid-row-delete').unbind('click').click(function() {
                var id = $(this).data('id');
                swal({
                    title: "Bạn có chắc chắn muốn xóa ?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Xác nhận",
                    showLoaderOnConfirm: true,
                    cancelButtonText: "Đóng",
                    preConfirm: function() {
                        return new Promise(function(resolve) {
                            $.ajax({
                                method: 'POST',
                                url: "<?php echo e(url('/admin/ajax/menulist_del')); ?>/"+ id,
                                data: {
                                    _method: 'DELETE',
                                    _token: "<?php echo e(csrf_token()); ?>",
                                },
                                success: function(data) {
                                    $.pjax.reload('#pjax-container');
                                    resolve(data);
                                    toastr.success(data);
                                }
                            });
                        });
                    }
                }).then(function(result) {
                    var data = result.value;
                    if (typeof data === 'object') {
                        if (data.status) {
                            swal(data.message, '', 'Thành công');
                        } else {
                            swal(data.message, '', 'Lỗi');
                        }
                    }
                });
            });

            // ajax status
            $('.grid-switch').bootstrapSwitch({
                size:'mini',
                onText: 'ON',
                offText: 'OFF',
                onColor: 'primary',
                offColor: 'default',
                onSwitchChange: function(event, state) {
                    $(this).val(state ? 'on' : 'off');
                }
            });

            $('.grid-switch-status').bootstrapSwitch({
                size:'mini',
                onText: 'ON',
                offText: 'OFF',
                onColor: 'primary',
                offColor: 'default',
                onSwitchChange: function(event, state){
                    $(this).val(state ? 'on' : 'off');
                    var id = $(this).data('key');
                    $.ajax({
                        url: "<?php echo e(url('/admin/ajax/status_menulist')); ?>/" + id,
                        type: "POST",
                        data: {
                            _token: "<?php echo e(csrf_token()); ?>",
                            _method: 'PUT'
                        },
                        success: function (data) {
                            toastr.success(data);
                        }
                    });
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogger\resources\views/admins/menulists/widgets/app.blade.php ENDPATH**/ ?>
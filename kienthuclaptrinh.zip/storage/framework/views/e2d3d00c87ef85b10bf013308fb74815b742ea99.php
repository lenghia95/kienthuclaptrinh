<script type="text/javascript">
    $(document).ready(function () {
        $("#valiForm").validate({
            rules: {
                slug: {
                    remote: {
                        url: "<?php echo e(url('/admin/ajax/posts_unique_slug')); ?>",
                        type: "get",
                        data: {
                            url: function () {
                                return $("input[name='slug']").val();
                            },
                            id: function () {
                                return $("input[name='slug']").attr('data-id');
                            },
                        },
                        async:false,
                        dataFilter: function (data) {
                            var json = JSON.parse(data);
                            if (json.msg == "true") {
                                return "\"" + "This value exists in database." + "\"";
                            } else {
                                return 'true';
                            }
                        }
                    },
                },
            },
        });
    });
</script>    
<?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/admins/posts/validate.blade.php ENDPATH**/ ?>
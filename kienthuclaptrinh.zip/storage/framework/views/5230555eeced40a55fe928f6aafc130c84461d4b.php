<?php $__env->startSection('content'); ?>
<meta property="og:url"           content="<?php echo e(Request::fullUrl()); ?>" />
<meta property="og:type"          content="website" />
<meta property="og:locale" content="vi_vn" />
<meta property="og:title"         content="<?php echo e($post->title); ?>" />
<meta property="og:description"   content="<?php echo e($post->description); ?>" />
<meta property="og:image"         content="<?php echo e(asset($post->thumbnail)); ?>" />
     <div class="col-sm-8 col-sm-12 col-lg-8">

         <!-- Breadcrumb -->
        <div class="fakeimg p-2 mt-2">
            <div class="news-ticker" >
                <ul>
                    <li>
                        <span>
                            <a href="<?php echo e(url('')); ?>" >
                                 <span>Trang chủ</span>
                            </a>
                        </span>
                    </li>
                    <li>
                        <span>
                            <i class="fa fa-angle-double-right"></i>
                            <a href="<?php echo e(url('category/'.$post->cSlug)); ?>" >
                                 <span><?php echo e($post->cName); ?></span>
                            </a>
                        </span>
                    </li>
                    
                    <li>
                        <span>
                            <i class="fa fa-angle-double-right"></i>
                            <span class="title"><?php echo e($post->title); ?></span>
                        </span>
                    </li>
                </ul>
            </div>
        </div>
        <!-- Breadcrumb -->


        <!-- main-content -->
        <div class="main-content">
                <div class="fakeimg p-3 mt-2">
                     <div class="row">
                        <div class="col-md-12">
                            <h3 class="entry-title">
                                <a><?php echo e($post->title); ?></a>
                            </h3>
                            <div class="newspaper-x-post-meta">
                                <div>
                                    
                                    <div class="mom-post-meta bp-meta single-post-meta">
                                        <span class="author vcard mr-2"><i class="fa fa-user"></i> <?php echo e($post->uName); ?> </span>
                                        <span class="mr-2">
                                            <i class="fa fa-clock-o"></i>
                                            <time datetime="2019-03-07T03:51:04+00:00" itemprop="datePublished" class="updated"><?php echo e(date('d/m/Y',strtotime($post->created_at))); ?></time>
                                        </span>
                                        <span class="mr-2"><i class="fa fa-eye"></i> <?php echo e($post->views); ?></span>
                                        <span class="mr-2"><i class="fa fa-comments"></i> <?php echo e($post->comments->count()); ?></span>
                                        <span> <i class="fa fa-tags"></i> </span><a href="<?php echo e(url('category/'.$post->cSlug)); ?>" class="badge badge-warning" style="color:#fff"><?php echo e($post->cName); ?></a>
                                    </div>
                                </div>
                                

                                <!-- post detail -->
                                    <section class="post-content"> 
                                        <?php echo $post->content; ?>

                                       
                                    </section>
                                <!-- post detail -->
                            </div>
                        </div>
                    </div>
                </div>
                    

                <!-- tags -->
                    <div class="fakeimg p-2 mt-2">
                        <div class="row">
                                <div class="col-md-12">
                                <h6 class="m-0"><i class="fa fa-tags"></i>Tags:
                                    <span> 
                                        <?php $__currentLoopData = App\Models\PostCategory::getCatsByPostId($post->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(url('category/'.$cat->slug)); ?>"><span class="badge badge-info"> <?php echo e($cat->name); ?> </span></a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </span>
                                </h6>
                            </div>
                        </div>
                    </div>
                    
                    <div class="icon-bar">
                        <?php echo Share::page(Request::fullUrl(), null, ['class' => 'facebook'])->facebook(); ?>

                        <?php echo Share::page(Request::fullUrl(), null, ['class' => 'twitter'])->twitter(); ?>

                        <?php echo Share::page(Request::fullUrl(), null, ['class' => 'google'])->googlePlus(); ?>

                        <?php echo Share::page(Request::fullUrl(), null, ['class' => 'linkedin'])->linkedin(); ?>

                    </div>
                    
                <!-- tags -->

                <!-- bình luận -->
                    <div class="fakeimg p-2 mt-2">
                        <h4> Bình luận:</h4>
                        

                        <div class="comment-show mb-5">
                            <!-- Comment parent -->
                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="media mb-2 comment-parent comment-<?php echo e($comment->id); ?>">
                                <img class="d-flex mr-2 border rounded comment-avatar" src="<?php echo e(( !empty($comment->avatar) ) ? asset($comment->avatar) : asset('uploads/users/user.png')); ?>" alt="<?php echo e($comment->fullname); ?>" title="<?php echo e($comment->fullname); ?>">
                                <div class="media-body comment-body">
                                    <div class="card bg-light p-2 card-edit-<?php echo e($comment->id); ?>">
                                        <div class="comment-content-<?php echo e($comment->id); ?>">
                                            <h5 class="mt-0"><?php echo e($comment->fullname); ?></h5>
                                            <div class="comment-body-content">
                                                <?php echo $comment->content; ?>

                                            </div>
                                        </div>
                                        <div class="form-edit-<?php echo e($comment->id); ?>">
                                            
                                        </div>
                                    </div>
                                    <div>
                                        <ul class="list-inline mb-1 comment-action">
                                            <li class="list-inline-item">
                                                <a class="reply" data-scrollto="#reply<?php echo e($comment->id); ?>" data-toggle="collapse" data-pell="<?php echo e($comment->id); ?>" href="#reply<?php echo e($comment->id); ?>" role="button" aria-expanded="false" aria-controls="reply<?php echo e($comment->id); ?>"><i class="fa fa-reply" aria-hidden="true"></i> Trả lời</a>
                                            </li>
                                            <?php if(Auth::check() && Auth::user()->fullname == $comment->fullname): ?>
                                            <li class="list-inline-item">
                                                <a href="javascript:void(0)" data-id="<?php echo e($comment->id); ?>" class="reply delete-comment"><i class="fa fa-trash" aria-hidden="true"></i> Xóa</a>
                                            </li>
                                            <li class="list-inline-item">
                                                <a href="javascript:void(0)" data-id="<?php echo e($comment->id); ?>" class="reply edit-comment"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Sửa</a>
                                            </li>
                                            <?php endif; ?>
                                            <li class="list-inline-item">
                                                <?php
                                                    $current = Carbon\Carbon::create(date('Y-m-d H:i:s',strtotime($comment->created_at)));
                                                ?>
                                                <?php if( $current->diffInMinutes() < 60): ?>
                                                    <?php echo e(($current->diffInMinutes() == 0) ? 1 : $current->diffInMinutes()); ?> phút
                                                <?php endif; ?>
                                                <?php if( $current->diffInHours() > 0 && $current->diffInHours() < 24): ?>
                                                    <?php echo e($current->diffInHours()); ?> giờ
                                                <?php endif; ?>
                                                <?php if( $current->diffInDays() > 0 && $current->diffInDays() < 30): ?>
                                                    <?php echo e($current->diffInDays()); ?> ngày
                                                <?php endif; ?>
                                                <?php if( $current->diffInMonths() > 0 && $current->diffInMonths() < 12): ?>
                                                    <?php echo e($current->diffInMonths()); ?> tháng
                                                <?php endif; ?>
                                                <?php if( $current->diffInYears() > 0): ?>
                                                    <?php echo e($current->diffInYears()); ?> năm
                                                <?php endif; ?>
                                            </li>
                                        </ul>
                                    </div>
                                    <!-- Comment children -->
                                    <div class="comment-children<?php echo e($comment->id); ?> comment-child">
                                        <?php $__currentLoopData = App\Models\Comment::getCommentsByParent($comment->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="media mb-2 comment-<?php echo e($comment->id); ?>" id="comment<?php echo e($comment->id); ?>">
                                            <img class="d-flex mr-2 border rounded comment-avatar" src="<?php echo e(( !empty($reply->avatar) ) ? asset($reply->avatar) : asset('uploads/users/user.png')); ?>" alt="<?php echo e($reply->fullname); ?>" title="<?php echo e($reply->fullname); ?>">
                                            <div class="media-body">
                                                <div class="card bg-light p-2 card-edit-<?php echo e($reply->id); ?>">
                                                   <div class="comment-content-<?php echo e($reply->id); ?>">
                                                        <h5 class="mt-0"><?php echo e($reply->fullname); ?></h5>
                                                        <div class="comment-body-content">
                                                            <?php echo $reply->content; ?>

                                                        </div>
                                                   </div>
                                                   <div class="form-edit-<?php echo e($reply->id); ?>"> </div>
                                                </div>
                                                <ul class="list-inline mb-1 comment-action">
                                                    <li class="list-inline-item">
                                                        <a class="reply" data-scrollto="#reply<?php echo e($comment->id); ?>" data-toggle="collapse" data-pell="<?php echo e($comment->id); ?>" href="#reply<?php echo e($comment->id); ?>" role="button" aria-expanded="false" aria-controls="reply<?php echo e($comment->id); ?>"><i class="fa fa-reply" aria-hidden="true"></i> Trả lời</a>
                                                    </li>
                                                    <?php if(Auth::check() && Auth::user()->id == $reply->uId): ?>
                                                    <li class="list-inline-item">
                                                        <a href="javascript:void(0)" data-id="<?php echo e($reply->id); ?>" class="reply delete-comment"><i class="fa fa-trash" aria-hidden="true"></i> Xóa</a>
                                                    </li>
                                                    <li class="list-inline-item">
                                                        <a href="javascript:void(0)" data-id="<?php echo e($reply->id); ?>" class="reply edit-comment"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Sửa</a>
                                                    </li>
                                                    <?php endif; ?>
                                                    <?php
                                                        $current = Carbon\Carbon::create(date('Y-m-d H:i:s',strtotime($reply->created_at)));
                                                    ?>
                                                    <li class="list-inline-item">
                                                        <?php if( $current->diffInMinutes() < 60): ?>
                                                            <?php echo e(($current->diffInMinutes() == 0) ? 1 : $current->diffInMinutes()); ?> phút
                                                        <?php endif; ?>
                                                        <?php if( $current->diffInHours() > 0 && $current->diffInHours() < 24): ?>
                                                            <?php echo e($current->diffInHours()); ?> giờ
                                                        <?php endif; ?>
                                                        <?php if( $current->diffInDays() > 0 && $current->diffInDays() < 30): ?>
                                                            <?php echo e($current->diffInDays()); ?> ngày
                                                        <?php endif; ?>
                                                        <?php if( $current->diffInMonths() > 0 && $current->diffInMonths() < 12): ?>
                                                            <?php echo e($current->diffInMonths()); ?> tháng
                                                        <?php endif; ?>
                                                        <?php if( $current->diffInYears() > 0): ?>
                                                            <?php echo e($current->diffInYears()); ?> năm
                                                        <?php endif; ?>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="collapse mb-1" id="reply<?php echo e($comment->id); ?>">
                                        <form method="POST" action="javascript:void(0)" accept-charset="UTF-8" class="postAjax" id="comment-reply">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="post" value="<?php echo e($post->id); ?>">
                                            <input type="hidden" name="comment" value="<?php echo e($comment->id); ?>">
                                            <div class="form-group textarea-comment">
                                                <textarea class="form-control comment" name="content" rows="1" placeholder="Nhập nội dung bình luận..."></textarea>
                                            </div>
                                            <input type="reset" class="d-none">
                                            
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="card mb-3 comment-form">
                            <div class="card-body p-2">
                                <form method="POST" action="javascript:void(0)" accept-charset="UTF-8" class="postAjax" id="comment0">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="post" value="<?php echo e($post->id); ?>">
                                    <div class="form-group textarea-comment">
                                        <textarea class="form-control comment" name="content" rows="1" placeholder="Nhập nội dung bình luận..."></textarea>
                                    </div>
                                    <input type="reset" class="d-none">
                                    
                                </form>
                            </div>
                        </div>
                    </div>
                <!-- tags -->
            </div>
        <!-- main-content -->
        
    </div>

        <!-- sidebar -->

    <div class="col-sm-4 col-sm-12 col-lg-4 sticky sidebar">

        <?php echo $__env->make('homes.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('homes.layouts.fanpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
    <div class="col-md-12">
        <div class="fakeimg p-1 mt-2">
            <div class="row">
                <div class="col-md-12">
                    <div class="box-title">
                        <h2 class="title">
                            <a href="/search/label/Break?&amp;max-results=10">Bài viết liên quan</a>
                        </h2>
                    </div>
                </div>
                
                <div class="slider-relate">
                    <?php $__currentLoopData = $postsRelate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 blogspot">
                        <div class="newspaper new-slider">
                            <a href="<?php echo e(url('post/'.$post->slug)); ?>">
                                <img src="<?php echo e(asset($post->thumbnail)); ?>" alt="<?php echo e($post->title); ?>">
                            </a>
                            <div class="first-tag">
                                <a class="badge badge-warning" href="<?php echo e(url('category/'.$post->cSlug)); ?>"><?php echo e($post->cName); ?></a>
                            </div>
                            <div class="bf-content-br"></div>
                            <div class="bf-content">
                                <h5 class="recent-title">
                                    <a href="<?php echo e(url('post/'.$post->slug)); ?>"><?php echo e($post->title); ?></a>
                                </h5>
                                <div class="mom-post-meta mom-w-meta">
                                    <span class="entry-date"><i class="fa fa-clock-o"></i> <?php echo e(date('d/m/Y', strtotime($post->cName) )); ?></span> -
                                    <span class="entry-date"><i class="fa fa-eye"></i> <?php echo e($post->views); ?> - </span>
                                    <span class="entry-date"><i class="fa fa-comments"></i> <?php echo e($post->comments->count()); ?> </span>
                                </div>
        
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script type="text/javascript">
    
        $(document).ready(function () {
            
            $(document).on( 'keydown', 'textarea', function (e){
                $(this).css('height', 'auto' );
                $(this).height( this.scrollHeight );
            });

            $(document).on( 'focus', 'textarea[name=content]', function (e){
                $(this).css('background-color', 'rgb(238, 238, 238)' );
            });

            <?php if(!Auth::check()): ?>
                var login = false;
            <?php else: ?> 
                var login = true;
            <?php endif; ?>

            $('textarea.comment').on('click', function(){
                if(login == false){
                    window.location.href="/login";
                }
            });

            $(document).on( "keypress", "#comment0", function(e) {
                if(e.which == 13) {
                    if(login == false){
                        window.location.href="/login";
                    }else if(login == true){
                        var option = $( this ).serializeArray();

                        if(option[2] == ''){
                            return false;
                        }else{
                            $.ajax({
                                type: "POST",
                                url: "<?php echo e(url("ajax/comment")); ?>",
                                data: {
                                    post_id: option[1].value,
                                    content: option[2].value,
                                }, 
                                success: function(data)
                                {
                                    // alert(data);return false;
                                    $('.comment-show').append(data);
                                    $('input[type=reset]').click();
                                }
                            });
                            return false;
                        }
                    }
                }
            });

            $(document).on( "keypress", "#comment-reply", function(e) {
                if(e.which == 13) {
                    if(login == false){
                        window.location.href="/login";
                    }else if(login == true){
                        var option = $( this ).serializeArray();
                        if(option[2] == ''){
                            return false;
                        }else{
                            $.ajax({
                                type: "POST",
                                url: "<?php echo e(url("ajax/comment-reply")); ?>",
                                data: {
                                    post_id: option[1].value,
                                    content: option[3].value,
                                    comment_id: option[2].value,
                                }, 
                                success: function(data)
                                {
                                    $('.comment-children'+ option[2].value).append(data);
                                    $('input[type=reset]').click();
                                }
                            });
                            return false;
                        }
                    }
                }
            });
            
            $(document).on('click', '.delete-comment', function(){
                var comment_id = $(this).data('id');
                var check = confirm('Bạn chắc chắn muốn xóa bình luận này!');
                if(check == true){
                    $.ajax({
                        type: "post",
                        url: "<?php echo e(url("ajax/comment-del")); ?>",
                        data: { comment_id: comment_id, _token: "<?php echo e(csrf_token()); ?>"},
                        success: function (data) {
                            if(data != ''){
                                $('.comment-'+comment_id).remove();
                            }
                        }
                    });
                    
                }else{return false}
            });


            $(document).on('click', '.edit-comment', function(){
                var comment_id = $(this).data('id')
                    content = $('.card-edit-'+ comment_id + ' .comment-body-content').text();
                   
                var html = '<form method="POST" action="javascript:void(0)" accept-charset="UTF-8" class="postAjax" id="edit-comment"><input type="hidden" name="comment_id" value="'+comment_id+'" /><div class="form-group textarea-comment"><textarea class="form-control comment" name="content" rows="1" placeholder="Nhập nội dung bình luận...">'+ content.trim() +'</textarea><span class="reply">Nhấn phím Esc để hủy</span></div><input type="reset" class="d-none"></form>';
                
                $('.comment-content-' + comment_id).css('display','none');
                $('.form-edit-'+comment_id).html(html);
                $( document ).on( 'keydown', function ( e ) {
                    if ( e.keyCode === 27 ) {
                        $('#edit-comment').hide();
                        $('.comment-content-' + comment_id).css('display','block');
                    }
                });
            });

            $(document).on( "keypress", "#edit-comment", function(e) {
                if(e.which == 13) {
                    var option = $( this ).serializeArray();
                   
                    if(option[1] == ''){
                        return false;
                    }else{
                        $.ajax({
                            type: "POST",
                            url: "<?php echo e(url("ajax/comment-edit")); ?>",
                            data: {
                                content: option[1].value,
                                comment_id: option[0].value,
                            }, 
                            success: function(data)
                            {
                                $('.card-edit-'+ option[0].value + ' .comment-body-content').text(data);
                                $('.comment-content-' + option[0].value).css('display','block');
                                $('#edit-comment').hide();
                            }
                        });
                        return false;
                    }
                }
            });

            $('.slider-relate').slick({
                autoplay:true,
                autoplaySpeed:1500,
                prevArrow: false,
                nextArrow: false,
                slidesToShow: 4, 
                slidesToScroll: 1,
                responsive: 
                [   
                    {
                        breakpoint: 992, settings: {
                            slidesToShow: 3, slidesToScroll: 1
                        }
                        
                    },{
                        breakpoint: 768, settings: {
                            slidesToShow: 2, slidesToScroll: 1
                        }
                        
                    },
                    {
                        breakpoint: 422, settings: {
                            slidesToShow: 1, slidesToScroll: 1
                        }
                        
                    }
                ]
            });
            
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('homes.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/homes/posts/post.blade.php ENDPATH**/ ?>
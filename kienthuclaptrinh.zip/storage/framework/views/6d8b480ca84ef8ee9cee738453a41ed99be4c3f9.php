<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="content-header">
    <h1>
        <?php echo e($title); ?>

        <small><?php echo e(config('admin.list')); ?></small>
    </h1>
    <!-- breadcrumb start -->
    <ol class="breadcrumb" style="margin-right: 30px;">
        <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(config('admin.home')); ?></a></li>
        <li><?php echo e($title); ?></li>
    </ol>
    <!-- breadcrumb end -->
</section>

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <div class="pull-right">
                        <div class="btn-group pull-right" style="margin-right: 10px">
                            <a class="btn btn-sm btn-twitter" title="Export"><i class="fa fa-download"></i><span class="hidden-xs"> <?php echo e(config('admin.export')); ?></span></a>
                            <button type="button" class="btn btn-sm btn-twitter dropdown-toggle" data-toggle="dropdown">
                                <span class="caret"></span>
                                <span class="sr-only">Toggle Dropdown</span>
                            </button>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="" target="_blank">All</a></li>
                                <li><a href="" target="_blank">Current page</a></li>
                                <li><a href="" target="_blank" class="export-selected">Selected rows</a></li>
                            </ul>
                        </div>
                    </div>

                </div>
                <div class="box-header with-border hide" id="filter-box">
                    <form action="" class="form-horizontal" pjax-container="" method="get">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="box-body">
                                    <div class="fields-group">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label"> ID</label>
                                            <div class="col-sm-8">
                                                <div class="input-group input-group-sm">
                                                    <div class="input-group-addon">
                                                        <i class="fa fa-pencil"></i>
                                                    </div>
                                                    <input type="text" class="form-control id" placeholder="ID" name="id" value="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-md-2"></div>
                                    <div class="col-md-8">
                                        <div class="btn-group pull-left">
                                            <button class="btn btn-info submit btn-sm"><i class="fa fa-search"></i>&nbsp;&nbsp;<?php echo e(config('admin.search')); ?></button>
                                        </div>
                                        <div class="btn-group pull-left " style="margin-left: 10px;">
                                            <a href="" class="btn btn-default btn-sm"><i class="fa fa-undo"></i>&nbsp;&nbsp;<?php echo e(config('admin.reset')); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- /.box-header -->
                <div class="box-body">
                    <table id="example" class="table table-hover table-striped table-bordered">
                        <thead>
                        <tr class="_table_title">
                            <th> </th>
                            <th>ID
                                <a class="fa fa-fw fa-sort" href=""></a>
                            </th>
                            <th><?php echo e(config('admin.title')); ?></th>
                            <th><?php echo e(config('admin.email')); ?></th>
                            <th><?php echo e(config('admin.content')); ?></th>
                            <th>Reply</th>
                            <th><?php echo e(config('admin.status')); ?></th>
                            <th><?php echo e(config('admin.action')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="minimal" >
                                </td>
                                <td><?php echo e($comment->id); ?></td>
                                <td><?php echo e($comment->title); ?></td>
                                <td><?php echo e($comment->email); ?></td>
                                <td><?php echo $comment->content; ?></td>
                                <td>
                                    <?php
                                        $parent = new App\Models\Comment;
                                    ?>
                                    <?php if($comment->parent == 0): ?>
                                        <span class="label label-primary">Level 1 comment</span>
                                   
                                    <?php elseif($parent->getItemReply($comment->parent)): ?>
                                       
                                        <?php echo e($parent->getItemReply($comment->parent)->email); ?>

                                        <br>
                                        <span class="label label-primary">Comment reply</span>
                                        <span class="label label-primary">
                                           ID: <?php echo e($parent->getItemReply($comment->parent)->id); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="label label-danger">
                                            BL Level1 đã xóa
                                        </span>
                                    <?php endif; ?>
                                    
                                        
                                        
                                    
                                </td>
                                <td align="center">
                                    <a data-key="<?php echo e($comment->id); ?>" data-status="<?php echo e($comment->status); ?>" class="status-contact label label-<?php echo e(($comment->status == 1) ? 'success' : 'warning'); ?>"> <?php echo e(($comment->status == 1) ? 'On' : 'Off'); ?> </a>
                                </td>
                                <td align="center">
                                    <a href="<?php echo e(route('comments.show',[ 'id' => $comment->id ])); ?>"><i class="fa fa-eye"></i></a>
                                    <a href="javascript:void(0);" data-id="<?php echo e($comment->id); ?>" class="grid-row-delete"><i class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            // ajax delete
            $('.grid-row-delete').unbind('click').click(function() {
                var id = $(this).data('id');
                swal({
                    title: "Bạn có chắc chắn muốn xóa ?",
                    icon:'error',
                    dangerMode: true,
                    buttons: ["Đóng", "Xác nhận"],

                }).then((willDelete) => {
                    if (willDelete) {
                        $.ajax({
                            method: 'POST',
                            url: "<?php echo e(url('/admin/ajax/comments_del')); ?>/"+ id,
                            data: {
                                _method: 'DELETE',
                                _token: "<?php echo e(csrf_token()); ?>",
                            },
                            success: function(data) {
                                location.reload();
                            }
                        });
                        swal("Bạn đã xó thành công!", {
                            buttons: false,
                            timer: 1000,
                            icon: "success"
                        });
                    }
                });
            });


            // // ajax status
            $(document).on('click', '.status-contact', function(){
                var id = $(this).data('key');
                var status = $(this).attr('data-status');
                if(status == 1){
                    $(this).removeClass('label-success').addClass('label-warning');
                    $(this).text('Off');
                    $(this).attr('data-status',0)
                }
                else if(status == 0){
                    $(this).text('On');
                    $(this).removeClass('label-warning').addClass('label-success');
                    $(this).attr('data-status',1)
                }
                
                $.ajax({
                    url: "<?php echo e(url('/admin/ajax/comments_status')); ?>/" + id,
                    type: "POST",
                    data: {
                        "status": status,
                        _token: "<?php echo e(csrf_token()); ?>",
                        _method: 'PUT'
                    },
                    success: function (data) {
                        toastr.success(data);
                    }
                });
            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/admins/comments/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="content-header">
    <h1>
        <?php echo e($title); ?>

        <small><?php echo e(config('admin.list')); ?></small>
    </h1>
    <!-- breadcrumb start -->
    <ol class="breadcrumb" style="margin-right: 30px;">
        <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(config('admin.home')); ?></a></li>
        <li><?php echo e($title); ?></li>
    </ol>
    <!-- breadcrumb end -->
</section>

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="pull-right">
                        <a href="" class="btn btn-success" data-toggle="modal" data-target="#flipFlop"> <i class="fa fa-save"></i> <?php echo e(config('admin.new')); ?></a>
                    </div>

                    <!-- The modal -->
                    <div class="modal fade" id="flipFlop" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true" >
                        <div class="modal-dialog" role="document" >
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <h4 class="modal-title" id="modalLabel">Add Sliders Image</h4>
                                </div>
                                <form action="<?php echo e(route('sliderimages.store')); ?>" method="POST" id="valiForm" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="box-body">
                                        <div class="fields-group">
                                            <div class="col-sm-12">
                                                <label for="title" class="control-label"><?php echo e(config('admin.title')); ?>*</label>
                                                <label for="title" generated="true" class="error"></label>
                                                <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                                                    <label class="error"><?php echo e($message); ?></label>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                <div class="input-group mb-10">
                                                    <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                                                    <input type="text" name="title" value="<?php echo e(old('title')); ?>" maxlength="255" class="form-control key" placeholder="<?php echo e(config('admin.title')); ?>" required>
                                                </div>
                                            </div>

                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                    <label for="image" class="control-label"><?php echo e(config('admin.image')); ?>*</label>
                                                    <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
                                                        <label class="error"><?php echo e($message); ?></label>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                    <input type="file" class="avatar" name="image"/>
                                                    
                                                </div>
                                            </div>

                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                    <label for="key" class="control-label"><?php echo e(config('admin.key')); ?>*</label>
                                                    <?php if ($errors->has('key')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('key'); ?>
                                                        <label class="error"><?php echo e($message); ?></label>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                    <select class="form-control parent_id select2-hidden-accessible" style="width: 100%;" name="key" data-value="" tabindex="-1" aria-hidden="true" required>
                                                        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($slider->id); ?>"><?php echo e($slider->key); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>


                                            <div class="col-sm-12">
                                                <label for="content" class="control-label"><?php echo e(config('admin.content')); ?>*</label>
                                                <div class="input-group mb-10">
                                                    <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                                                    <textarea name="content" class="form-control" rows="3" placeholder="<?php echo e(config('admin.content')); ?>"></textarea>
                                                </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <label for="html" class="control-label">Html content</label>
                                                <div class="input-group mb-10">
                                                    <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                                                    <textarea name="html" class="form-control" rows="3" placeholder="html content"></textarea>
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                    <!-- /.box-body -->
                                    <div class="box-footer">
                                        <div class="col-md-12">
                                            <div class="btn-group pull-right">
                                                <button type="submit" class="btn btn-primary"><?php echo e(config('admin.submit')); ?></button>
                                            </div>
                                            <div class="btn-group pull-right" style="margin-right:10px">
                                                <button type="reset" class="btn btn-warning"><?php echo e(config('admin.reset')); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.box-footer -->
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- The modal -->

                </div>

                <!-- /.box-header -->
                <table id="example" class="table table-hover table-striped table-bordered">
                    <thead>
                    <tr class="_table_title">
                        <th> </th>
                        <th>ID
                            <a class="fa fa-fw fa-sort" href=""></a>
                        </th>
                        <th><?php echo e(config('admin.title')); ?></th>
                        <th><?php echo e(config('admin.image')); ?></th>
                        <th><?php echo e(config('admin.key')); ?></th>
                        <th><?php echo e(config('admin.action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $sliderimages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="icheckbox_minimal-blue" aria-checked="false" aria-disabled="false" style="position: relative;">
                                    <input type="checkbox" class="grid-row-checkbox" data-id="1" style="position: absolute; opacity: 0;">
                                </div>
                            </td>
                            <td><?php echo e($slider->id); ?></td>
                            <td><?php echo e($slider->title); ?></td>
                            <td align="center">
                                <img width="300" class="img-thumbnail" src="<?php echo e(asset($slider->image)); ?>" alt="">
                            </td>
                            <td>
                                <?php $slide = new App\Models\Slider; ?>
                                <a><?php echo e($slide->getItem($slider->key)->key); ?></a>
                            </td>
                            <td align="center">
                                <a href="<?php echo e(route('sliderimages.edit',[ 'id' => $slider->id ])); ?>"><i class="fa fa-edit"></i></a>
                                <a href="javascript:void(0);" data-id="<?php echo e($slider->id); ?>" class="grid-row-delete"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            
            // ajax delete
            $('.grid-row-delete').unbind('click').click(function() {
                var id = $(this).data('id');
                swal({
                    title: "Bạn có chắc chắn muốn xóa ?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Xác nhận",
                    showLoaderOnConfirm: true,
                    cancelButtonText: "Đóng",
                    preConfirm: function() {
                        return new Promise(function(resolve) {
                            $.ajax({
                                method: 'POST',
                                url: "<?php echo e(url('/admin/ajax/sliderimages_del')); ?>/"+ id,
                                data: {
                                    _method: 'PUT',
                                    _token: "<?php echo e(csrf_token()); ?>",
                                },
                                success: function(data) {
                                    // console.log(data); return false;
                                    $.pjax.reload('#pjax-container');
                                    resolve(data);
                                    toastr.success(data);
                                }
                            });
                        });
                    }
                }).then(function(result) {
                    var data = result.value;
                    if (typeof data === 'object') {
                        if (data.status) {
                            swal(data.message, '', 'Thành công');
                        } else {
                            swal(data.message, '', 'Lỗi');
                        }
                    }
                });
            });

            $('#valiForm').validate();
            
        });
    </script>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogger\resources\views/admins/sliderimages/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <!-- succeeded -->
       <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- succeeded -->
        <h1>
            <?php echo e($title); ?>

            <small><?php echo e(config('admin.list')); ?></small>
        </h1>
        <!-- breadcrumb start -->
        <ol class="breadcrumb" style="margin-right: 30px;">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(config('admin.home')); ?></a></li>
            <li><?php echo e($title); ?></li>
        </ol>
        <!-- breadcrumb end -->
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <form action="<?php echo e(route('configs.store')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                    <!-- general form elements disabled -->
                    <div class="box box-warning">
                        <div class="box-header with-border">
                            <h3 class="box-title">GUI Settings</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                        <!-- text input -->
                            <div class="form-group">
                                <label>Sitename</label>
                                <input type="text" class="form-control" placeholder="Lara" name="sitename" value="<?php echo e($configs->sitename); ?>">
                            </div>
                            <div class="form-group">
                                <label>Sitename First Word</label>
                                <input type="text" class="form-control" placeholder="Lara" name="sitename_part1" value="<?php echo e($configs->sitename_part1); ?>">
                            </div>
                            <div class="form-group">
                                <label>Sitename Second Word</label>
                                <input type="text" class="form-control" placeholder="Admin 1.0" name="sitename_part2" value="<?php echo e($configs->sitename_part2); ?>">
                            </div>
                            <div class="form-group">
                                <label>Sitename Short (2/3 Characters)</label>
                                <input type="text" class="form-control" placeholder="LA" maxlength="2" name="sitename_short" value="<?php echo e($configs->sitename_short); ?>">
                            </div>
                            <div class="form-group">
                                <label>Site Description</label>
                                <input type="text" class="form-control" placeholder="Description in 140 Characters" maxlength="140" name="site_description" value="<?php echo e($configs->site_description); ?>">
                            </div>
                            <!-- checkbox -->
                            <div class="form-group">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="sidebar_search" <?php if($configs->sidebar_search): ?> checked <?php endif; ?>>
                                        Show Search Bar
                                    </label>
                                </div>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="show_messages" <?php if($configs->show_messages): ?> checked <?php endif; ?>>
                                        Show Messages Icon
                                    </label>
                                </div>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="show_notifications" <?php if($configs->show_notifications): ?> checked <?php endif; ?>>
                                        Show Notifications Icon
                                    </label>
                                </div>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="show_tasks" <?php if($configs->show_tasks): ?> checked <?php endif; ?>>
                                        Show Tasks Icon
                                    </label>
                                </div>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="show_rightsidebar" <?php if($configs->show_rightsidebar): ?> checked <?php endif; ?>>
                                        Show Right SideBar Icon
                                    </label>
                                </div>
                            </div>
                            <!-- select -->
                            <div class="form-group">
                                <label>Skin Color</label>
                                <select class="form-control" name="skin">
                                    <?php $__currentLoopData = $skins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name=>$property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($property); ?>" <?php if($configs->skin == $property): ?> selected <?php endif; ?>><?php echo e($name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Layout</label>
                                <select class="form-control" name="layout">
                                    <?php $__currentLoopData = $layouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name=>$property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($property); ?>" <?php if($configs->layout == $property): ?> selected <?php endif; ?>><?php echo e($name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Default Email Address</label>
                                <input type="text" class="form-control" placeholder="To send emails to others via SMTP" maxlength="100" name="default_email" value="<?php echo e($configs->default_email); ?>">
                            </div>
                        </div><!-- /.box-body -->
                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary"><?php echo e(config('admin.save')); ?></button>
                        </div><!-- /.box-footer -->
                    </div><!-- /.box -->
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogger\resources\views/admins/configs/index.blade.php ENDPATH**/ ?>
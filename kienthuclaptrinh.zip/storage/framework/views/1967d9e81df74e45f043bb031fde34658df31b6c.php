<?php $__env->startSection('content'); ?>

<?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="content-header">
    <h1>
        <?php echo e($title); ?>

        <small><?php echo e(config('admin.list')); ?></small>
        
    </h1>
    <!-- breadcrumb start -->
    <ol class="breadcrumb" style="margin-right: 30px;">
        <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(config('admin.home')); ?></a></li>
        <li>Auth</li>
        <li><?php echo e($title); ?></li>
    </ol>
    <!-- breadcrumb end -->
</section>

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <div class="pull-right">
                        <div class="btn-group pull-right" style="margin-right: 10px">
                            <a class="btn btn-sm btn-twitter" title="Export"><i class="fa fa-download"></i><span class="hidden-xs"> <?php echo e(config('admin.export')); ?></span></a>
                            <button type="button" class="btn btn-sm btn-twitter dropdown-toggle" data-toggle="dropdown">
                                <span class="caret"></span>
                                <span class="sr-only">Toggle Dropdown</span>
                            </button>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="" target="_blank">All</a></li>
                                <li><a href="" target="_blank">Current page</a></li>
                                <li><a href="" target="_blank" class="export-selected">Selected rows</a></li>
                            </ul>
                        </div>

                        <div class="btn-group pull-right" style="margin-right: 10px">
                            <a href="" class="btn btn-sm btn-success" title="New" data-toggle="modal" data-target="#flipFlop">
                                <i class="fa fa-save"></i><span class="hidden-xs">&nbsp;&nbsp;<?php echo e(config('admin.new')); ?></span>
                            </a>
                        </div>

                    </div>
                    <span>
                    <a class="btn btn-sm btn-primary grid-refresh" title="Refresh"><i class="fa fa-refresh"></i> <span class="hidden-xs"><?php echo e(config('admin.refresh')); ?></span></a>
                        <div class="btn-group" style="margin-right: 10px" data-toggle="buttons">
                            <label class="btn btn-sm btn-dropbox filter-btn " title="Filter">
                                <input type="checkbox"><i class="fa fa-filter"></i><span class="hidden-xs">&nbsp;&nbsp;<?php echo e(config('admin.filter')); ?></span>
                            </label>
                        </div>
                    </span>
                </div>
                <div class="box-header with-border hide" id="filter-box">
                    <form action="" class="form-horizontal" pjax-container="" method="get">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="box-body">
                                    <div class="fields-group">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label"> ID</label>
                                            <div class="col-sm-8">
                                                <div class="input-group input-group-sm">
                                                    <div class="input-group-addon">
                                                        <i class="fa fa-pencil"></i>
                                                    </div>
                                                    <input type="text" class="form-control id" placeholder="ID" name="id" value="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-md-2"></div>
                                    <div class="col-md-8">
                                        <div class="btn-group pull-left">
                                            <button class="btn btn-info submit btn-sm"><i class="fa fa-search"></i>&nbsp;&nbsp;<?php echo e(config('admin.search')); ?></button>
                                        </div>
                                        <div class="btn-group pull-left " style="margin-left: 10px;">
                                            <a href="" class="btn btn-default btn-sm"><i class="fa fa-undo"></i>&nbsp;&nbsp;<?php echo e(config('admin.reset')); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- /.box-header -->
                <table id="example" class="table table-hover table-striped table-bordered">
                    <thead>
                    <tr class="_table_title">
                        <th> </th>
                        <th>ID
                            <a class="fa fa-fw fa-sort" href=""></a>
                        </th>
                        <th><?php echo e(config('admin.email')); ?></th>
                        <th><?php echo e(config('admin.name')); ?></th>
                        
                        <th><?php echo e(config('admin.image')); ?></th>
                        <th><?php echo e(config('admin.status')); ?></th>
                        <th><?php echo e(config('admin.created_at')); ?></th>
                        <th><?php echo e(config('admin.action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="icheckbox_minimal-blue" aria-checked="false" aria-disabled="false" style="position: relative;">
                                    <input type="checkbox" class="grid-row-checkbox" data-id="1" style="position: absolute; opacity: 0;">
                                </div>
                            </td>
                            <td><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->fullname); ?></td>
                            
                            <?php if($user->avatar): ?>
                            <td>
                                <img src="<?php echo e(asset( $user->avatar )); ?>" alt="" class="img-thumbnail" width="50" height="50"/>
                            </td>
                            <?php else: ?>
                                <td><strong>Chưa cập nhật</strong></td>
                            <?php endif; ?>
                            <td>
                                <span data-key="<?php echo e($user->id); ?>" data-status="<?php echo e($user->status); ?>" class="_status status-user label label-<?php echo e(($user->status == 1) ? 'success' : 'warning'); ?>"> <?php echo e(($user->status == 1) ? 'Đã duyệt' : 'Chưa duyệt'); ?> </span>
                                
                            </td>
                            <td><?php echo e(date('d/m/Y', strtotime($user->created_at) )); ?></td>
                            <td>
                                <a href=""><i class="fa fa-eye"></i></a>
                                <a href="<?php echo e(route('users.edit',['id' => $user->id])); ?>"><i class="fa fa-edit"></i></a>
                                <a href="#" data-id="<?php echo e($user->id); ?>" class="grid-row-delete">
                                    <i class="fa fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
                <!-- The modal -->
                <div class="modal fade" id="flipFlop" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <h4 class="modal-title" id="modalLabel">Add User</h4>
                            </div>
                            <form action="<?php echo e(route('users.store')); ?>" method="POST" enctype="multipart/form-data" id="valiForm">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="fields-group row">
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <label for="username" class="control-label"><?php echo e(config('admin.name')); ?>*</label>
                                                <label for="username" generated="true" class="error"></label>
                                                <div class="input-group mb-10">
                                                    <span class="input-group-addon"><i class="fa fa-pencil fa-fw"></i></span>
                                                    <input type="text" name="username" value="" class="form-control username" placeholder="<?php echo e(config('admin.username')); ?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <label for="name" class="control-label"><?php echo e(config('admin.email')); ?>*</label>
                                                <label for="email" generated="true" class="error"></label>
                                                <div class="input-group mb-10">
                                                    <span class="input-group-addon"><i class="fa fa-envelope-o fa-fw"></i></span>
                                                    <input type="text"  name="email" value="" class="form-control name" placeholder="<?php echo e(config('admin.email')); ?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <label for="name" class="control-label"><?php echo e(config('admin.password')); ?>*</label>
                                                <label for="password" generated="true" class="error"></label>
                                                <div class="input-group mb-10">
                                                    <span class="input-group-addon"><i class="fa fa-eye-slash fa-fw"></i></span>
                                                    <input type="password" id="password" name="password" value="" class="form-control name" placeholder="<?php echo e(config('admin.password')); ?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <label for="name" class="control-label"><?php echo e(config('admin.password_confirmation')); ?>*</label>
                                                <label for="repassword" generated="true" class="error"></label>
                                                <div class="input-group mb-10">
                                                    <span class="input-group-addon"><i class="fa fa-eye-slash fa-fw"></i></span>
                                                    <input type="password"  name="repassword" value="" class="form-control name" placeholder="<?php echo e(config('admin.password_confirmation')); ?>">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <label for="name" class="control-label"><?php echo e(config('admin.role')); ?>*</label>
                                                <label for="roles" generated="true" class="error"></label>
                                                <select class="form-control roles" style="width: 100%;" name="roles[]" multiple="multiple" data-placeholder="<?php echo e(config('admin.role')); ?>" data-value="">
                                                    <?php $__currentLoopData = App\Models\Role::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <label for="name" class="control-label"><?php echo e(config('admin.fullname')); ?>*</label>
                                                <div class="input-group mb-10">
                                                    <span class="input-group-addon"><i class="fa fa-eye-slash fa-fw"></i></span>
                                                    <input type="text" name="fullname" value="" class="form-control name" placeholder="<?php echo e(config('admin.fullname')); ?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <label for="avatar" class="control-label"><?php echo e(config('admin.image')); ?></label>
                                                <input type="file" class="avatar" name="avatar" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary"><?php echo e(config('admin.submit')); ?></button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <?php echo $__env->make('admins.users.validate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).ready(function() {
            // ajax delete
            $('.grid-row-delete').unbind('click').click(function() {
                var id = $(this).data('id');
                swal({
                    title: "Bạn có chắc chắn muốn xóa ?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Xác nhận",
                    showLoaderOnConfirm: true,
                    cancelButtonText: "Đóng",
                    preConfirm: function() {
                        return new Promise(function(resolve) {
                            $.ajax({
                                method: 'POST',
                                url: "<?php echo e(url('/admin/ajax/user_del')); ?>/"+ id,
                                data: {
                                    _method: 'DELETE',
                                    _token: "<?php echo e(csrf_token()); ?>",
                                },
                                success: function(data) {

                                    $.pjax.reload('#pjax-container');
                                    resolve(data);
                                    toastr.success('<?php echo e(config('admin.delete_succeeded')); ?>');
                                }
                            });
                        });
                    }
                }).then(function(result) {
                    var data = result.value;
                    if (typeof data === 'object') {
                        if (data.status) {
                            swal(data.message, '', 'Thành công');
                        } else {
                            swal(data.message, '', 'Lỗi');
                        }
                    }
                });
            });

            // // ajax status
            // $('.grid-switch-status').bootstrapSwitch({
            //     size:'mini',
            //     onText: 'ON',
            //     offText: 'OFF',
            //     onColor: 'primary',
            //     offColor: 'default',
            //     onSwitchChange: function(event, state){
            //         $(this).val(state ? 'on' : 'off');
            //         var id = $(this).data('key');
            //         var value = $(this).val();
            //         $.ajax({
            //             url: "<?php echo e(url('/admin/ajax/status_user')); ?>/" + id,
            //             type: "POST",
            //             data: {
            //                 "status": value,
            //                 _token: "<?php echo e(csrf_token()); ?>",
            //                 _method: 'PUT'
            //             },
            //             success: function (data) {
            //                 toastr.success(data);
            //             }
            //         });
            //     }
            // });

            // // ajax status
            $(document).on('click', '.status-user', function(){
                var id = $(this).data('key');
                var status = $(this).attr('data-status');
                if(status == 1){
                    $(this).removeClass('label-success').addClass('label-warning');
                    $(this).text('Chưa duyệt');
                    $(this).attr('data-status', 0)
                }
                else if(status == 0){
                    $(this).text('Đã duyệt');
                    $(this).removeClass('label-warning').addClass('label-success');
                    $(this).attr('data-status', 1)
                }
                
                $.ajax({
                    url: "<?php echo e(url('/admin/ajax/user_status')); ?>/" + id,
                    type: "POST",
                    data: {
                        "status": status,
                        _token: "<?php echo e(csrf_token()); ?>",
                        _method: 'PUT'
                    },
                    success: function (data) {
                        toastr.success(data);
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogger\resources\views/admins/users/index.blade.php ENDPATH**/ ?>
<div class="fakeimg p-3 mt-2">
    <div id="tag_cloud-2" class="widget widget_tag_cloud">
        <div class="widget-head">
            <h3 class="widget-title text-light p-2">Fanpage facebook </h3>
        </div>
        <div class="tagcloud">
            <div class="fb-page" data-href="https://www.facebook.com/kienthuclaptrinhdl/"  data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
                <blockquote cite="https://www.facebook.com/kienthuclaptrinhdl/" class="fb-xfbml-parse-ignore">
                    <a href="https://www.facebook.com/kienthuclaptrinhdl/">Kiến Thức Lập Trình</a>
                </blockquote>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/homes/layouts/fanpage.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            <?php echo e($title); ?>

            <small><?php echo e(config('admin.show')); ?></small>
        </h1>

        <!-- breadcrumb start -->
        <ol class="breadcrumb" style="margin-right: 30px;">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(config('admin.home')); ?></a></li>
            <li>
                <?php echo e($title); ?>

            </li>
            <li>
                <?php echo e($comment->id); ?>

            </li>
        </ol>

        <!-- breadcrumb end -->

    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-12">
                        <div class="box box-info">
                            <div class="box-header with-border">
                                <h3 class="box-title"><?php echo e($title); ?>.<?php echo e(config('admin.detail')); ?></h3>
    
                                <div class="box-tools">
                                    <div class="btn-group pull-right" style="margin-right: 5px">
                                        <form action="<?php echo e(route('comments.destroy',['id'=>$comment->id])); ?>" method="post" onsubmit="return confirm('<?php echo e(config('admin.delete_confirm')); ?>')">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> <?php echo e(config('admin.delete')); ?></button>
                                        </form>
                                    </div>
                                    
                                    <div class="btn-group pull-right" style="margin-right: 5px">
                                        <a href="<?php echo e(route('comments.index')); ?>" class="btn btn-sm btn-default" title="List">
                                            <i class="fa fa-list"></i><span class="hidden-xs"> <?php echo e(config('admin.list')); ?></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <!-- /.box-header -->
                            <!-- form start -->
                            <div class="form-horizontal">
    
                                <div class="box-body">
    
                                    <div class="fields-group">
    
                                        <div class="form-group ">
                                            <label class="col-sm-2 control-label">ID</label>
                                            <div class="col-sm-8">
                                                <div class="box box-solid box-default no-margin box-show">
                                                    <!-- /.box-header -->
                                                    <div class="box-body">
                                                        <?php echo e($comment->id); ?>&nbsp;
                                                    </div>
                                                    <!-- /.box-body -->
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <label class="col-sm-2 control-label"><?php echo e(config('admin.name')); ?></label>
                                            <div class="col-sm-8">
                                                <div class="box box-solid box-default no-margin box-show">
                                                    <!-- /.box-header -->
                                                    <div class="box-body">
                                                        <?php echo e($comment->title); ?>&nbsp;
                                                    </div>
                                                    <!-- /.box-body -->
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <label class="col-sm-2 control-label"><?php echo e(config('admin.email')); ?></label>
                                            <div class="col-sm-8">
                                                <div class="box box-solid box-default no-margin box-show">
                                                    <!-- /.box-header -->
                                                    <div class="box-body">
                                                        <?php echo e($comment->email); ?>&nbsp;
                                                    </div>
                                                    <!-- /.box-body -->
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="form-group ">
                                            <label class="col-sm-2 control-label"><?php echo e(config('admin.phone')); ?></label>
                                            <div class="col-sm-8">
                                                <div class="box box-solid box-default no-margin box-show">
                                                    <!-- /.box-header -->
                                                    <div class="box-body">
                                                            <?php echo e($comment->content); ?>&nbsp;
                                                    </div>
                                                    <!-- /.box-body -->
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group ">
                                            <label class="col-sm-2 control-label"><?php echo e(config('admin.created_at')); ?></label>
                                            <div class="col-sm-8">
                                                <div class="box box-solid box-default no-margin box-show">
                                                    <!-- /.box-header -->
                                                    <div class="box-body">
                                                        <?php echo e($comment->created_at); ?>&nbsp;
                                                    </div>
                                                    <!-- /.box-body -->
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <label class="col-sm-2 control-label"><?php echo e(config('admin.updated_at')); ?></label>
                                            <div class="col-sm-8">
                                                <div class="box box-solid box-default no-margin box-show">
                                                    <!-- /.box-header -->
                                                    <div class="box-body">
                                                        <?php echo e($comment->updated_at); ?>&nbsp;
                                                    </div>
                                                    <!-- /.box-body -->
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group ">
                                            <label class="col-sm-2 control-label"><?php echo e(config('admin.status')); ?></label>
                                            <div class="col-sm-8">
                                                <div class="box box-solid box-default no-margin box-show">
                                                    <!-- /.box-header -->
                                                    <div class="box-body" >
                                                        <a data-key="<?php echo e($comment->id); ?>" data-status="<?php echo e($comment->status); ?>" class="status-contact label label-<?php echo e(($comment->status === 1) ? 'success' : 'warning'); ?>">
                                                            <?php echo e(($comment->status === 1) ? 'On' : 'Off'); ?>

                                                        </a>&nbsp;
                                                    </div>
                                                    <!-- /.box-body -->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
    
                                </div>
                                <!-- /.box-body -->
                            </div>
                        </div>
                    </div>
    
                    <div class="col-md-12">
                    </div>
                </div>
            </div>
        </div>
    
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            // // ajax status
            $(document).on('click', '.status-contact', function(){
                var id = $(this).data('key');
                var status = $(this).attr('data-status');
                if(status == 1){
                    $(this).removeClass('label-success').addClass('label-warning');
                    $(this).text('Off');
                    $(this).attr('data-status',0)
                }
                else if(status == 0){
                    $(this).text('On');
                    $(this).removeClass('label-warning').addClass('label-success');
                    $(this).attr('data-status',1)
                }

                $.ajax({
                    url: "<?php echo e(url('/admin/ajax/comments_status')); ?>/" + id,
                    type: "POST",
                    data: {
                        "status": status,
                        _token: "<?php echo e(csrf_token()); ?>",
                        _method: 'PUT'
                    },
                    success: function (data) {
                        toastr.success(data);
                    }
                });
            });
        });
    </script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/admins/comments/show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('menulist'); ?>
<form action="<?php echo e(route('menulists.store')); ?>" class="_form_bk mt-10 ml-10 mb-10" method="POST" id="valiMenulist">
    <?php echo csrf_field(); ?>
    
    <h3 class="modal-title ml-15" id="modalLabel"><?php echo e(config('admin.new')); ?></h3>
    <div class="modal-body">
        <div class="fields-group row">
            <div class="form-group">
                <div class="col-sm-12 mb-10">
                    <label for="menugroup" class="control-label">Menu Group*</label>
                    <?php if ($errors->has('menugroup')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('menugroup'); ?>
                        <label class="error"><?php echo e($message); ?></label>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    <select class="form-control parent_id select2-hidden-accessible" style="width: 100%;" name="menugroup" data-value="" tabindex="-1" aria-hidden="true" required>
                        <?php $menuGroups = new App\Models\Menugroup; ?>
                        <?php $__currentLoopData = $menuGroups->getMenugroups(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menugroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($menugroup->id); ?>"><?php echo e($menugroup->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-12">
                    <label for="name" class="control-label"><?php echo e(config('admin.name')); ?>*</label>
                    <label for="_name" generated="true" class="error"></label>
                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                        <label for="_name" generated="true" class="error"><?php echo e($message); ?></label>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    <input type="text" name="name" id="_name" value="<?php echo e(old('name')); ?>" class="form-control" placeholder="<?php echo e(config('admin.name')); ?>" required>
                    <br>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-12">
                    <label for="url" class="control-label"><?php echo e(config('admin.url')); ?>*</label>
                    <label for="url" generated="true" class="error"></label>
                    <?php if ($errors->has('url')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('url'); ?>
                        <label class="error"><?php echo e($message); ?></label>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    <input type="text"  name="url" value="<?php echo e(old('url')); ?>" class="form-control uri" placeholder="<?php echo e(config('admin.url')); ?>" required />
                    <br>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-12 mb-10">
                    <label for="parent" class="control-label"><?php echo e(config('admin.parent_id')); ?>*</label>
                    <input type="hidden" name="parent">
                    <?php if ($errors->has('parent')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('parent'); ?>
                        <label class="error"><?php echo e($message); ?></label>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    <select class="form-control parent_id select2-hidden-accessible" style="width: 100%;" name="parent" data-value="" tabindex="-1" aria-hidden="true" required>
                        <option value="0">Không</option>
                        <?php echo $parents; ?>

                    </select>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-12 mb-10">
                    <label for="status" class="control-label"><?php echo e(config('admin.status')); ?>:</label>
                    <input type="checkbox" name="status" checked data-toggle="toggle" data-size="xs" data-onstyle="primary" data-offstyle="warning" class="edit-status" value="1">
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-12">
                    <label for="sort" class="control-label"><?php echo e(config('admin.sort')); ?></label>
                    <label for="sort" generated="true" class="error"></label>
                    <input type="number"  name="sort" value="<?php echo e(old('sort')); ?>" class="form-control" placeholder="<?php echo e(config('admin.sort')); ?>" >
                </div>
            </div>
        </div>
    </div>
    <div class="modal-footer">
        <button type="submit" class="btn btn-primary"><?php echo e(config('admin.submit')); ?></button>
    </div>
</form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admins.menulists.widgets.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/admins/menulists/index.blade.php ENDPATH**/ ?>
<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> <?php echo App\Models\Config::getByKey('sitename_part2'); ?>

    </div>
    <?php echo App\Models\Config::getByKey('copyright'); ?>

</footer>
<?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/admins/layouts/footer.blade.php ENDPATH**/ ?>
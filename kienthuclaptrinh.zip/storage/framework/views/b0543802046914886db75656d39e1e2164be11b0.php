<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>Dashboard<small> </small> </h1>
    <!-- breadcrumb start -->
    <ol class="breadcrumb" style="margin-right: 30px;">
        <li><a href="http://shopcart.local/public/admin"><i class="fa fa-dashboard"></i> Home</a></li>
    </ol>
    <!-- breadcrumb end -->
</section>
<section class="content"> 
    <div class="row">
        <div class="col-md-4">
            <div class="small-box bg-aqua"> 
                <div class="inner"> 
                    <h3>38</h3> 
                    <p>Product total</p> 
                </div> 
                <div class="icon"><i class="fa fa-tags"></i> </div> 
                <a href="/admin/shop_product" class="small-box-footer"> More&nbsp;<i class="fa fa-arrow-circle-right"></i> </a> 
            </div>
        </div>
        <div class="col-md-4">
            <div class="small-box bg-green"> 
                <div class="inner"> 
                    <h3>0</h3> 
                    <p>Order total</p> 
                </div> 
                <div class="icon"> <i class="fa fa-shopping-cart"></i> </div> 
                <a href="/admin/shop_order" class="small-box-footer"> More&nbsp;<i class="fa fa-arrow-circle-right"></i> </a> 
            </div>
        </div>
        <div class="col-md-4">
            <div class="small-box bg-yellow"> 
                <div class="inner"> 
                    <h3>0</h3> 
                    <p>Customer total</p> 
                </div> 
                <div class="icon"> <i class="fa fa-user"></i> </div> 
                <a href="/admin/shop_customer" class="small-box-footer"> More&nbsp; <i class="fa fa-arrow-circle-right"></i> </a> 
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="box"> 
                <div class="box-header with-border"> 
                    <h3 class="box-title">In this month</h3> 
                    <div class="box-tools pull-right"> </div>
                    <!-- /.box-tools --> 
                </div>
                <!-- /.box-header --> 
                <div class="box-body" style="display: block;"> 
                    <div class="box-body"> 
                        <div class="row">
                            <div class="chartjs-size-monitor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;">
                                <div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                                    <div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div>
                                </div>
                                <div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                                    <div style="position:absolute;width:200%;height:200%;left:0; top:0"></div>
                                </div>
                            </div> 
                            <!-- /.col --> 
                            <canvas id="chart-days-in-month" width="1079" height="308" style="display: block; width: 1079px; height: 308px;" class="chartjs-render-monitor"></canvas> 
                            <!-- /.col --> 
                        </div>
                            <!-- /.row --> 
                    </div> 
                    <script type="text/javascript"> 
                        function format_number(n) {
                            return n.toFixed(0).replace(/./g, function(c, i, a) {
                                return i > 0 && c !=="." && (a.length - i) % 3===0 ? "," + c: c;
                            });
                        }
                        $(document).ready(function($) {
                            var ctx=document.getElementById('chart-days-in-month').getContext('2d');
                            var chart=new Chart(ctx, {
                                // The type of chart we want to create
                                type: 'bar', // The data for our dataset
                                data: {
                                    // type: 'category',
                                    labels: ["1/03", "2/03", "3/03", "4/03", "5/03", "6/03", "7/03", "8/03", "9/03", "10/03", "11/03", "12/03", "13/03", "14/03", "15/03", "16/03", "17/03", "18/03", "19/03", "20/03", "21/03", "22/03"], datasets: [ {
                                        label: "Total amount", backgroundColor: 'rgba(225,0,0,0.4)', borderColor: "rgb(231, 53, 253)", borderCapStyle: 'square', pointHoverRadius: 8, pointHoverBackgroundColor: "yellow", pointHoverBorderColor: "brown", data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], showLine: true, // disable for a single dataset,
                                        yAxisID: "y-axis-gravity", fill: false, type: 'line', lineTension: 0.1,
                                    }
                                    , {
                                        label: "Total order", backgroundColor: 'rgb(138, 199, 214)', borderColor: 'rgb(138, 199, 214)', pointHoverRadius: 8, pointHoverBackgroundColor: "brown", pointHoverBorderColor: "yellow", data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], showLine: true, // disable for a single dataset,
                                        yAxisID: "y-axis-density", spanGaps: true, lineTension: 0.1,
                                    }
                                    , ]
                                }
                                , // Configuration options go here
                                options: {
                                    responsive: true, legend: {
                                        display: true,
                                    }
                                    , layout: {
                                        padding: {
                                            left: 10, right: 10, top: 0, bottom: 0
                                        }
                                    }
                                    , scales: {
                                        yAxes: [ {
                                            position: "left", id: "y-axis-density", ticks: {
                                                beginAtZero: true, max: 0 + 5, min: 0, stepSize: 2,
                                            }
                                            , scaleLabel: {
                                                display: true, labelString: 'Total order', fontSize: 15,
                                            }
                                        }
                                        , {
                                            position: "right", id: "y-axis-gravity", ticks: {
                                                beginAtZero:true, callback: function(label, index, labels) {
                                                    return format_number(label);
                                                }
                                                ,
                                            }
                                            , scaleLabel: {
                                                display: true, labelString: 'Total amount (Bit)', fontSize: 15
                                            }
                                        }
                                        ]
                                    }
                                    , tooltips: {
                                        callbacks: {
                                            label: function(tooltipItem, data) {
                                                var label=data.datasets[tooltipItem.datasetIndex].label || '';
                                                if (label) {
                                                    label +=': ';
                                                }
                                                label +=format_number(tooltipItem.yLabel);
                                                return label;
                                            }
                                        }
                                    }
                                }
                            });
                        });
                    </script> 
                </div>
                <!-- /.box-body --> 
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="box"> 
                <div class="box-header with-border"> 
                    <h3 class="box-title">In 12 months</h3> 
                    <div class="box-tools pull-right"> </div>
                    <!-- /.box-tools --> 
                    </div><!-- /.box-header --> 
                    <div class="box-body" style="display: block;"> 
                    <!-- /.box-header --> 
                    <div class="box-body"> 
                        <div class="row">
                            <div class="chartjs-size-monitor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;">
                                <div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                                    <div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div>
                                </div>
                                <div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                                    <div style="position:absolute;width:200%;height:200%;left:0; top:0"></div>
                                </div>
                            </div> 
                            <!-- /.col --> 
                            <canvas id="chartjs-1" width="1079" height="269" class="chartjs-render-monitor" style="display: block; width: 1079px; height: 269px;"></canvas> 
                            <!-- /.col --> 
                        </div> <!-- /.row --> 
                    </div> 
                
                <script> 
                    function format_number(n) {
                        return n.toFixed(0).replace(/./g, function(c, i, a) {
                            return i > 0 && c !=="." && (a.length - i) % 3===0 ? "," + c: c;
                        });
                    }
        
                    $(document).ready(function($) {
                        var ctx=document.getElementById('chartjs-1').getContext('2d');
                        var chart=new Chart(ctx, {
                            // The type of chart we want to create
                            type: 'bar', // The data for our dataset
                            data: {
                                "labels":["03/2018", "04/2018", "05/2018", "06/2018", "07/2018", "08/2018", "09/2018", "10/2018", "11/2018", "12/2018", "01/2019", "02/2019", "03/2019"], "datasets":[ {
                                    "label": "Total amount", "data": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "fill": false, "backgroundColor": [ "rgba(191, 25, 232, 0.2)", "rgba(191, 25, 232, 0.2)", "rgba(191, 25, 232, 0.2)", "rgba(191, 25, 232, 0.2)", "rgba(255, 99, 132, 0.2)", "rgba(255, 159, 64, 0.2)", "rgba(255, 205, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(54, 162, 235, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(201, 203, 207, 0.2)", "rgba(181, 147, 50, 0.2)", "rgba(232, 130, 81, 0.2)", ], "borderColor": [ "rgb(191, 25, 232)", "rgb(191, 25, 232)", "rgb(191, 25, 232)", "rgb(191, 25, 232)", "rgb(255, 99, 132)", "rgb(255, 159, 64)", "rgb(255, 205, 86)", "rgb(75, 192, 192)", "rgb(54, 162, 235)", "rgb(153, 102, 255)", "rgb(201, 203, 207)", "rgb(181, 147, 50)", "rgb(232, 130, 81)", ], "borderWidth": 1, type: "bar",
                                }
                                , {
                                    "label": "Line total amount", "data": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "fill": false, "backgroundColor": "red", "borderColor": "red", "borderWidth": 1, type: "line",
                                }
                                ]
                            }
                            , options: {
                                responsive: true, legend: {
                                    display: true,
                                }
                                , layout: {
                                    padding: {
                                        left: 10, right: 10, top: 0, bottom: 0
                                    }
                                }
                                , tooltips: {
                                    callbacks: {
                                        label: function(tooltipItem, data) {
                                            var label=data.datasets[tooltipItem.datasetIndex].label || '';
                                            if (label) {
                                                label +=': ';
                                            }
                                            label +=format_number(tooltipItem.yLabel);
                                            return label;
                                        }
                                    }
                                }, 
                                scales: {
                                    yAxes: [{
                                        position: "left", // id: "y-axis-amount",
                                        ticks: {
                                            beginAtZero:true, callback: function(label, index, labels) {
                                                return format_number(label);
                                            }
                                            ,
                                        }
                                        , scaleLabel: {
                                            display: true, labelString: 'Bit', fontSize: 15
                                        }
                                    }]
                                },
                            },
                        });
                    });
                </script> 
                </div>
                <!-- /.box-body --> 
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="box box-info box-solid"> 
                <div class="box-header with-border"> 
                    <h3 class="box-title">New customer</h3> 
                    <div class="box-tools pull-right"> </div>
                    <!-- /.box-tools --> 
                </div>
                <!-- /.box-header --> 
                <div class="box-body" style="display: block;"> 
                    <table class="table"> 
                        <thead> 
                            <tr> 
                                <th>Id</th> 
                                <th>Email</th> 
                                <th>Name</th> 
                                <th>Phone</th> 
                                <th>Time</th> 
                            </tr> 
                        </thead> 
                        <tbody>

                        </tbody> 
                    </table> 
                </div>
                <!-- /.box-body --> 
            </div>
        </div>
    </div> 
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogger\resources\views/admins/dashboards/index.blade.php ENDPATH**/ ?>
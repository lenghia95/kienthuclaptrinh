<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <!-- succeeded -->
       <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- succeeded -->
        <h1>
            <?php echo e($title); ?>

            <small><?php echo e(config('admin.list')); ?></small>
        </h1>
        <!-- breadcrumb start -->
        <ol class="breadcrumb" style="margin-right: 30px;">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(config('admin.home')); ?></a></li>
            <li><?php echo e($title); ?></li>
        </ol>
        <!-- breadcrumb end -->
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <!-- /.box-header -->
                    <div class="row">
                        <div class="col-md-4">
                            <?php echo $__env->yieldContent('menugroup'); ?>
                        </div>

                        <div class="col-md-8">
                            <table class="table table-hover table-striped table-bordered mt-10">
                                <thead>
                                <tr class="_table_title">
                                    <th> </th>
                                    <th>ID
                                        <a class="fa fa-fw fa-sort" href=""></a>
                                    </th>
                                    <th><?php echo e(config('admin.name')); ?></th>
                                    <th><?php echo e(config('admin.key')); ?></th>
                                    <th><?php echo e(config('admin.status')); ?></th>
                                    <th><?php echo e(config('admin.action')); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $menuGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <div class="icheckbox_minimal-blue" aria-checked="false" aria-disabled="false" style="position: relative;">
                                                <input type="checkbox" class="grid-row-checkbox" data-id="1" style="position: absolute; opacity: 0;">
                                            </div>
                                        </td>
                                        <td><?php echo e($menuGroup->id); ?></td>
                                        <td><?php echo e($menuGroup->name); ?></td>
                                        <td><?php echo e($menuGroup->key); ?></td>
                                        <td>
                                            <?php if($menuGroup->status == 1): ?>
                                                <input type="checkbox" checked class="grid-switch-status" checked data-key="<?php echo e($menuGroup->id); ?>" value="">
                                            <?php else: ?>
                                                <input type="checkbox" class="grid-switch-status" data-key="<?php echo e($menuGroup->id); ?>" value="">
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('menugroups.edit',['id' => $menuGroup->id])); ?>" data-toggle="modal"><i class="fa fa-edit"></i></a>
                                            <a href="#" data-id="<?php echo e($menuGroup->id); ?>" class="grid-row-delete">
                                                <i class="fa fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $("#valiForm").validate({
                rules: {
                    key: {
                        remote: {
                            url: "<?php echo e(url('/admin/ajax/unique_key')); ?>",
                            type: "get",
                            data: {
                                key: function () {
                                    return $("input[name='key']").val();
                                },
                                id: function () {
                                    return $("input[name='key']").attr('data-id');
                                },
                            },
                            dataFilter: function (data) {
                                var json = JSON.parse(data);
                                if (json.msg == "true") {
                                    return "\"" + "This value exists in database." + "\"";
                                } else {
                                    return 'true';
                                }
                            }
                        },
                    },
                },
            });
            
            //ajax delete
            $('.grid-row-delete').unbind('click').click(function() {
                var id = $(this).data('id');
                swal({
                    title: "Bạn có chắc chắn muốn xóa ?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Xác nhận",
                    showLoaderOnConfirm: true,
                    cancelButtonText: "Đóng",
                    preConfirm: function() {
                        return new Promise(function(resolve) {
                            $.ajax({
                                method: 'POST',
                                url: "<?php echo e(url('/admin/ajax/menugroup_del')); ?>/"+ id,
                                data: {
                                    _method: 'DELETE',
                                    _token: "<?php echo e(csrf_token()); ?>",
                                },
                                success: function(data) {
                                    $.pjax.reload('#pjax-container');
                                    resolve(data);
                                    toastr.success(data);
                                }
                            });
                        });
                    }
                }).then(function(result) {
                    var data = result.value;
                    if (typeof data === 'object') {
                        if (data.status) {
                            swal(data.message, '', 'Thành công');
                        } else {
                            swal(data.message, '', 'Lỗi');
                        }
                    }
                });
            });

            // $('#_name').on('blur', function(){
            //     var name = $(this).val();
            //     $('#_slug').val(convertSlug(name));
            // });

            // ajax status

            $('.grid-switch').bootstrapSwitch({
                size:'mini',
                onText: 'ON',
                offText: 'OFF',
                onColor: 'primary',
                offColor: 'default',
                onSwitchChange: function(event, state) {
                    $(this).val(state ? 'on' : 'off');
                }
            });

            $('.grid-switch-status').bootstrapSwitch({
                size:'mini',
                onText: 'ON',
                offText: 'OFF',
                onColor: 'primary',
                offColor: 'default',
                onSwitchChange: function(event, state){
                    $(this).val(state ? 'on' : 'off');
                    var id = $(this).data('key');
                    var value = $(this).val();
                    $.ajax({
                        url: "<?php echo e(url('/admin/ajax/status_menugroup')); ?>/" + id,
                        type: "POST",
                        data: {
                            "status": value,
                            _token: "<?php echo e(csrf_token()); ?>",
                            _method: 'PUT'
                        },
                        success: function (data) {
                            toastr.success(data);
                        }
                    });
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogger\resources\views/admins/menugroups/widgets/app.blade.php ENDPATH**/ ?>
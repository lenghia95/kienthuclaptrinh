<?php $__env->startSection('content'); ?>
    <!-- Breadcrumb -->
    <div class="col-sm-8 col-sm-12 col-lg-8">
        <div class="fakeimg p-2 mt-2">
            <div class="news-ticker" >
                <ul>
                    <li>
                        <span>
                            <a href="<?php echo e(url('/')); ?>" >
                                <span>Trang chủ</span>
                            </a>
                        </span>
                    </li>
                    <li>
                        <span>
                            <i class="fa fa-angle-double-right"></i>
                            <span class="title">Giới thiệu</span>
                        </span>
                    </li>
                </ul>
            </div>
        </div>

        <div class="fakeimg mt-2 p-2">
            <?php echo $about->content; ?>

        </div>
        <!-- main-content -->
    </div>

    <div class="col-sm-4 col-sm-12 col-lg-4 sticky sidebar">
        <?php echo $__env->make('homes.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('homes.layouts.fanpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('homes.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/homes/pages/about.blade.php ENDPATH**/ ?>
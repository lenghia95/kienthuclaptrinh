<script type="text/javascript">
    $(document).ready(function(){
        $("#valiForm").validate({
            rules: {
                username: {
                    required: true,
                    minlength: 2,
                    maxlength: 20
                },

                email:    {
                    required: true,
                    email: true,
                    remote: {
                        url: "<?php echo e(url('/admin/ajax/user_check_email')); ?>",
                        type: "get",
                        data: {
                            email: function () {
                                var seg4 = "<?php echo e(Request::segment(4)); ?>";
                                if(seg4 != 'edit'){
                                    return $("input[name='email']").val();
                                }else{
                                    return '';
                                }
                            }
                        },
                        dataFilter: function (data) {
                            var json = JSON.parse(data);
                            if (json.msg == "true") {
                                return "\"" + "Email đã tồn tại!" + "\"";
                            } else {
                                return 'true';
                            }
                        }
                    },
                },
                password: {
                    required: true,
                    minlength: 6,
                    maxlength: 32
                },
                repassword: {
                    equalTo: "#password",
                },
                roles: {
                    required: true,
                }
            },
            messages: {
                username: {
                    required:  "Vui lòng nhập tên",
                    minlength: "Tên không được ít hơn 2 ký tự",
                    maxlength: "Tên không được nhiều hơn 20 ký tự"
                },
                email: {
                    required:  "Vui lòng nhập email",
                    email:     "Bạn phải nhập đúng định dạng email",
                    // remote:    "Email đã tồn tại"
                },
                password: {
                    required:  "Vui lòng nhập mật khẩu",
                    minlength: "Mật khẩu không được ít hơn 6 ký tự",
                    maxlength: "Mật khẩu không được nhiều hơn 32 ký tự"
                },
                repassword: {
                    equalTo: "Mật khẩu chưa khớp",
                },
                roles: {
                    required: "Vui lòng chọn vai trò",
                }
            }
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\blogger\resources\views/admins/users/validate.blade.php ENDPATH**/ ?>
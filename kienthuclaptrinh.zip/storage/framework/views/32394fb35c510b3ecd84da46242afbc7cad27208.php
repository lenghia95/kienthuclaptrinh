<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <!-- succeeded -->
    <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- succeeded -->
        <h1>
            <?php echo e($title); ?>

            <small><?php echo e(config('admin.list')); ?></small>
        </h1>
        <!-- breadcrumb start -->
        <ol class="breadcrumb" style="margin-right: 30px;">
            <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> <?php echo e(config('admin.home')); ?></a></li>
            <li><?php echo e($title); ?></li>
        </ol>
        <!-- breadcrumb end -->
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <!-- /.box-header -->
                    <div class="row">
                        <div class="col-md-4">
                            <?php echo $__env->yieldContent('roles'); ?>
                        </div>

                        <div class="col-md-8">
                            <div class="box-body">
                                <table id="example" class="table table-hover table-striped table-bordered">
                                    <thead>
                                    <tr class="_table_title">
                                        <th> </th>
                                        <th>ID
                                            <a class="fa fa-fw fa-sort" href=""></a>
                                        </th>
                                        <th><?php echo e(config('admin.name')); ?></th>
                                        <th>Display Name</th>
                                        <th><?php echo e(config('admin.description')); ?></th>
                                        <th><?php echo e(config('admin.created_at')); ?></th>
                                        <th><?php echo e(config('admin.action')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="checkbox" class="minimal" >
                                            </td>
                                            <td><?php echo e($role->id); ?></td>
                                            <td><?php echo e($role->name); ?></td>
                                            <td><?php echo e($role->display_name); ?></td>
                                            <td><?php echo e($role->description); ?></td>
                                            <td><?php echo e(date('d/m/Y', strtotime($role->created_at) )); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('roles.edit',['id' => $role->id])); ?>" data-toggle="modal"><i class="fa fa-edit"></i></a>
                                                <a href="#" data-id="<?php echo e($role->id); ?>" class="grid-row-delete">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script type="text/javascript">
        $(document).ready(function(){

            //ajax delete
            $('.grid-row-delete').unbind('click').click(function() {
                var id = $(this).data('id');
                swal({
                    title: "You definitely want to delete?",
                    icon:'error',
                    dangerMode: true,
                    buttons: ["Cancel", "Yes"],

                }).then((willDelete) => {
                    if (willDelete) {
                        $.ajax({
                            method: 'POST',
                            url: "<?php echo e(url('/admin/ajax/role_del')); ?>/"+ id,
                            data: {
                                _method: 'DELETE',
                                _token: "<?php echo e(csrf_token()); ?>",
                            },

                            success: function(data) {
                                if(data == 'true'){
                                    swal("Delete success!", {

                                        buttons: false,
                                        timer: 1000,
                                        icon: "success"
                                    });
                                    window.location.href="/admin/roles"
                                }else{
                                    swal("Sorry, You are not authorized!", {
                                        buttons: false,
                                        timer: 1000,
                                        icon: "error"
                                    });
                                }
                            }
                        });
                    }
                });

            });

            // $('#_name').on('blur', function(){
            //     var name = $(this).val();
            //     $('#_slug').val(convertSlug(name));
            // });
        });
        $(function () {

            $("#valiForm").validate({
                rules:{
                    name:    {
                        remote: {
                            url: "<?php echo e(url('/admin/ajax/role_unique_name')); ?>",
                            type: "get",
                            data: {
                                name: function () {
                                    return $("input[name='name']").val();
                                },
                                id: function () {
                                    return $("input[name='name']").attr('data-id');
                                }
                            },
                            dataFilter: function (data) {
                                var json = JSON.parse(data);
                                if (json.msg == "true") {
                                    return "\"" + "This value exists in database" + "\"";
                                } else {
                                    return 'true';
                                }
                            }
                        },
                    },
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/admins/roles/widgets/app.blade.php ENDPATH**/ ?>
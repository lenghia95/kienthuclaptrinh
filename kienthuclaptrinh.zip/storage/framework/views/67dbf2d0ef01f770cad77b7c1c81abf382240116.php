<?php $__env->startSection('menugroup'); ?>
<form action="<?php echo e(route('menugroups.store')); ?>" class="_form_bk mt-10 ml-10 mb-10" method="POST" id="valiForm">
    <?php echo csrf_field(); ?>
    <h3 class="modal-title ml-15" id="modalLabel"><?php echo e(config('admin.new')); ?></h3>
    <div class="modal-body">
        <div class="fields-group row">
            <div class="form-group">
                <div class="col-sm-12">
                    <label for="name" class="control-label"><?php echo e(config('admin.name')); ?>*</label>
                    <label for="_name" generated="true" class="error"></label>
                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                        <label for="_name" generated="true" class="error"> <?php echo e($message); ?></label>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    <input type="text" name="name" id="_name" value="<?php echo e(old('name')); ?>" class="form-control name" placeholder="<?php echo e(config('admin.name')); ?>" required><br>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-12">
                    <label for="key" class="control-label"><?php echo e(config('admin.key')); ?>*</label>
                    <label for="key" generated="true" class="error"></label>
                    <?php if ($errors->has('key')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('key'); ?>
                        <label for="key" generated="true" class="error"> <?php echo e($message); ?></label>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    <input type="text" name="key" value="<?php echo e(old('key')); ?>" class="form-control key" placeholder="<?php echo e(config('admin.key')); ?>" required><br>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-12">
                    <label for="description" class="control-label"><?php echo e(config('admin.status')); ?>:</label>
                    <div class="input-group mb-10">
                        <input type="checkbox" name="status"  class="grid-switch" value="on">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-12">
                    <label for="description" class="control-label"><?php echo e(config('admin.description')); ?></label>
                    <textarea class="form-control" placeholder="<?php echo e(config('admin.description')); ?>" cols="30" rows="3" name="description"></textarea>
                </div>
            </div>
        </div>
    </div>
    <div class="modal-footer">
        <button type="submit" name="submit" class="btn btn-primary"><?php echo e(config('admin.submit')); ?></button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.menugroups.widgets.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogger\resources\views/admins/menugroups/index.blade.php ENDPATH**/ ?>
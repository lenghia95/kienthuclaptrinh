<!DOCTYPE html>
<html>

<?php echo $__env->make('admins.layouts.link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css">
    .modal {
        overflow-x: hidden;
        overflow-y: auto;
    }
   
   
</style>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
    <style>
        #flipFlop {
            overflow: auto !important;
        }
    </style>
    <?php echo $__env->make('admins.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Left side column. contains the logo and sidebar -->

    <?php echo $__env->make('admins.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper" >
        
        <?php echo $__env->yieldContent('content'); ?>

    </div>
    <!-- /.content-wrapper -->
    <?php echo $__env->make('admins.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Control Sidebar -->

        

    <!-- /.control-sidebar -->
    <!-- Add the sidebar's background. This div must be placed
         immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<?php echo $__env->make('admins.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/admins/layouts/app.blade.php ENDPATH**/ ?>
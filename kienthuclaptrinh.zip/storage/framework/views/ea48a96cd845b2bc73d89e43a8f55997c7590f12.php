<?php $__env->startSection('content'); ?>
    <div class="col-sm-8 col-sm-12 col-lg-8">
        <div class="fakeimg p-2 mt-2">
            <h3><?php echo e($page->title); ?></h3>
            <?php echo $page->content; ?>

        </div>
        <?php $__currentLoopData = App\Models\Category::getCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php 
            $obj = new App\Models\Post;
            $post = $obj->getPostByCat($cat->slug); 
        ?> 
            <?php if($post): ?>
            
                <div class="fakeimg p-1 mt-2">
                    <div class="row">

                        <div class="col-md-12">
                            <div class="box-title">
                                <h2 class="title">
                                    <a href="<?php echo e(url('category/'.$cat->slug)); ?>"><?php echo e($cat->name); ?></a>
                                </h2>
                            </div>
                        </div>
                    
                        <div class="col-md-6">
                            <div class="newspaper">
                                <a href="<?php echo e(url('post/'.$post->slug)); ?>">
                                    <img src="<?php echo e(asset($post->thumbnail)); ?>" alt="<?php echo e($post->title); ?>">
                                </a>
                                <div class="first-tag">
                                    <a class="badge badge-warning" href="<?php echo e(url('category/'.$cat->slug)); ?>"><?php echo e($cat->name); ?></a>
                                </div>
                                <div class="bf-content-br"></div>
                                <div class="bf-content">
                                    <h5 class="recent-title">
                                        <a href="<?php echo e(url('post/'.$post->slug)); ?>"><?php echo e($post->title); ?></a>
                                    </h5>
                                    <div class="mom-post-meta mom-w-meta">
                                        <span class="entry-date"><i class="fa fa-clock-o"></i> <?php echo e(date('d/m/Y',strtotime($post->created_at))); ?></span>  -  
                                        <span class="entry-date"><i class="fa fa-eye"></i> <?php echo e($post->views); ?> - </span>
                                        <span class="entry-date"><i class="fa fa-comments"></i> <?php echo e($post->comments->count()); ?> </span>
                                    </div>
                                </div>
                            </div>
                            <div class="content-post">
                                    <?php echo str_limit($post->description, 150); ?>

                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="post-news newspaper-home">
                                <?php $__currentLoopData = App\Models\Post::getPostsByCat($cat->slug); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($key < 5 && $key != 0): ?>
                                        
                                        <div class="mpw-post">
                                            <div class="post-img main-sidebar-element">
                                                <a href="<?php echo e(url('post/'.$post->slug)); ?>">
                                                    <img src="<?php echo e(asset($post->thumbnail)); ?>" alt="<?php echo e($post->title); ?>" >
                                                </a>
                                            </div>
                                            <div class="details has-feature-image">
                                                <h6>
                                                    <a href="<?php echo e(url('post/'.$post->slug)); ?>" title="<?php echo e($post->title); ?>"><?php echo e($post->title); ?></a>
                                                </h6>
                                                
                                            </div>
                                            <div class="mom-post-meta mom-w-meta">
                                                <span class="entry-date"><i class="fa fa-clock-o"></i> <?php echo e(date('d/m/Y',strtotime($post->created_at))); ?></span>  -
                                                <span class="entry-date"><i class="fa fa-eye"></i> <?php echo e($post->views); ?> - </span>
                                                <span class="entry-date"><i class="fa fa-comments"></i> <?php echo e($post->comments->count()); ?> </span>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>  
                    
                    </div>
                </div>

            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="fakeimg p-1 mt-2">
            <div class="row">
                <div class="col-md-12">
                    <div class="box-title">
                        <h2 class="title">
                            <a href="/search/label/Break?&amp;max-results=10">Bài viết mới</a>
                        </h2>
                    </div>
                </div>

                <div class="slider-blog">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <div class="col-md-4 blogspot">
                            <div class="newspaper new-slider">
                                <a href="<?php echo e(url('post/'.$post->slug)); ?>">
                                    <img src="<?php echo e(asset($post->thumbnail)); ?>"  alt="<?php echo e($post->title); ?>">
                                </a>
                                <div class="first-tag">
                                    <a class="badge badge-warning" href="<?php echo e(url('category/'.$post->cSlug)); ?>"><?php echo e($post->name); ?></a>
                                </div>
                                <div class="bf-content-br"></div>
                                <div class="bf-content">
                                    <h5 class="recent-title">
                                        <a href="<?php echo e(url('post/'.$post->slug)); ?>"><?php echo e($post->title); ?></a>
                                    </h5>
                                    <div class="mom-post-meta mom-w-meta">
                                        <span class="entry-date"><i class="fa fa-clock-o"></i> <?php echo e(date('d/m/Y',strtotime($post->title) )); ?></span>  -  
                                        <span class="entry-date"><i class="fa fa-eye"></i> <?php echo e($post->views); ?> - </span>
                                        <span class="entry-date"><i class="fa fa-comments"></i> <?php echo e($post->comments->count()); ?> </span>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    
    </div>


        <!-- sidebar -->

    <div class="col-sm-4 col-sm-12 col-lg-4 sticky sidebar">

        <?php echo $__env->make('homes.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('homes.layouts.fanpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

   
<?php $__env->stopSection(); ?>


<?php echo $__env->make('homes.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kienthuclaptrinh\resources\views/homes/pages/index.blade.php ENDPATH**/ ?>
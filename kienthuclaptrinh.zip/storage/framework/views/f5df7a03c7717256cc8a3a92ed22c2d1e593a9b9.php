<?php $__env->startSection('category'); ?>
<form action="<?php echo e(route('categories.store')); ?>" class="_form_bk mt-10 ml-10 mb-10" method="POST" id="valiMenulist">
    <?php echo csrf_field(); ?>
    <h3 class="modal-title ml-15" id="modalLabel"><?php echo e(config('admin.new')); ?></h3>
    <div class="modal-body">
        <div class="fields-group row">
            
            <div class="form-group">
                <div class="col-sm-12">
                    <label for="name" class="control-label"><?php echo e(config('admin.name')); ?>*</label>
                    <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control" placeholder="<?php echo e(config('admin.name')); ?>" required>
                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                        <label for="name" generated="true" class="error"><?php echo e($message); ?></label>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    <br>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-12">
                    <label for="slug" class="control-label"><?php echo e(config('admin.slug')); ?>*</label>
                    <input type="text"  name="slug" value="<?php echo e(old('slug')); ?>" class="form-control uri" placeholder="<?php echo e(config('admin.slug')); ?>" required />
                    <?php if ($errors->has('slug')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('slug'); ?>
                        <label class="error"><?php echo e($message); ?></label>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    <br>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-12 mb-10">
                    <label for="parent" class="control-label"><?php echo e(config('admin.parent_id')); ?>*</label>
                    <select class="form-control parent_id select2-hidden-accessible" style="width: 100%;" name="parent" data-value="" tabindex="-1" aria-hidden="true" required>
                        <option value="0">No Parent</option>
                        <?php echo $parents; ?>

                    </select>
                    <?php if ($errors->has('parent')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('parent'); ?>
                        <label class="error"><?php echo e($message); ?></label>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-12 mb-10">
                    <label for="status" class="control-label"><?php echo e(config('admin.status')); ?>:</label>
                    <input type="checkbox" name="status"  class="grid-switch" value="on">
                </div>
            </div>
           
            <div class="form-group">
                <div class="col-sm-12">
                    <label for="sort" class="control-label"><?php echo e(config('admin.sort')); ?></label>
                    <input type="number"  name="sort" value="<?php echo e(old('sort')); ?>" class="form-control" placeholder="<?php echo e(config('admin.sort')); ?>" />
                </div>
            </div>
        </div>
    </div>
    <div class="modal-footer">
        <button type="submit" class="btn btn-primary"><?php echo e(config('admin.submit')); ?></button>
    </div>
</form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admins.categories.widgets.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blogger\resources\views/admins/categories/index.blade.php ENDPATH**/ ?>
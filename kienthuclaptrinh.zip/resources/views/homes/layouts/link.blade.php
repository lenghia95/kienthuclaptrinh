<link rel="stylesheet" href="{{ asset('homes/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('homes/css/style.css') }}">
<link rel="stylesheet" href="{{ asset('homes/css/responsive.css') }}">
<link rel="stylesheet" href="{{ asset('homes/css/post.css') }}">
<link rel="stylesheet" href="{{ asset('homes/css/slick.css') }}">
<link rel="stylesheet" href="{{ asset('homes/css/slick-theme.css') }}">
<link href="https://fonts.googleapis.com/css?family=Oswald|Quicksand|Roboto&display=swap" rel="stylesheet">

<link rel="stylesheet" href="{{ asset('homes/navbar/css/bootnavbar.css') }}">
<link href="{{ asset($Setting['favicon']) }}" rel="shortcut icon" type="image/x-icon">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
@stack('link')

